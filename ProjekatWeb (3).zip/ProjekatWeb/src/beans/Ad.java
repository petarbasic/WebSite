package beans;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class Ad {
	private String id;
	private String seller;
	private String name;
	private String description;
	private int price;
	private int dislikes;
	private int likes;
	//private RestCateg restCateg;
	private boolean active;
	private boolean deleted;
	private String begindate;
	private String enddate;
	private String image;
	private List<Review> reviews;
	private String category;
	private String city;
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Ad() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ad(String id, String name, String description, int price, int dislikes, int likes, boolean active,boolean deleted,
			String begindate, String enddate, String image, ArrayList<Review> reviews,String category,String city, String seller) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.dislikes = dislikes;
		this.likes = likes;
		this.active = active;
		this.begindate = begindate;
		this.enddate = enddate;
		this.image = image;
		this.reviews = reviews;
		this.deleted=deleted;
		this.category=category;
		this.city=city;
		this.seller=seller;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getDislikes() {
		return dislikes;
	}

	public void setDislikes(int dislikes) {
		this.dislikes = dislikes;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getBegindate() {
		return begindate;
	}

	public void setBegindate(String begindate) {
		this.begindate = begindate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public List<Review> getReviews() {
		return reviews;
	}

	public void setReviews(List<Review> reviews) {
		this.reviews = reviews;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}
	
}

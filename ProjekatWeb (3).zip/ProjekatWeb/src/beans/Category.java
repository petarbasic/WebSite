package beans;

import java.util.HashMap;

public class Category {
	private String id;
	private String name;
	private String description;
	private boolean deleted;
	private HashMap<String,Ad> ads;
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(String id, String name, String description, HashMap<String, Ad> ads, boolean deleted) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.ads = ads;
		this.deleted=deleted;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public HashMap<String, Ad> getAds() {
		return ads;
	}
	public void setAds(HashMap<String, Ad> ads) {
		this.ads = ads;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
}

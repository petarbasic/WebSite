package beans;

public class Message {
	private String id;
	private String adname;
	private String user;
	private String title;
	private String content;
	private String datetime;
	private boolean read;
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Message(String id, String adname, String user, String title, String content, String datetime,boolean read) {
		super();
		this.id = id;
		this.adname = adname;
		this.user = user;
		this.title = title;
		this.content = content;
		this.datetime = datetime;
		this.read=read;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public boolean isRead() {
		return read;
	}
	public void setRead(boolean read) {
		this.read = read;
	}
	
}

package beans;

public class Review {
	
	private String adname;
	private String id;
	private String buyerId;
	private String title;
	private String content;
	private String image;
	private boolean desctrue;
	private boolean asagreed;
	private boolean deleted;
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Review(String adname, String id, String buyerId, String title, String content, String image,
			boolean desctrue, boolean asagreed, boolean deleted) {
		super();
		this.adname = adname;
		this.id = id;
		this.buyerId = buyerId;
		this.title = title;
		this.content = content;
		this.image = image;
		this.desctrue = desctrue;
		this.asagreed = asagreed;
		this.deleted = deleted;
	}
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public boolean isDesctrue() {
		return desctrue;
	}
	public void setDesctrue(boolean desctrue) {
		this.desctrue = desctrue;
	}
	public boolean isAsagreed() {
		return asagreed;
	}
	public void setAsagreed(boolean asagreed) {
		this.asagreed = asagreed;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
}

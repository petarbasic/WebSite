package beans;

public enum Role {
	Kupac,Prodavac,Admin
}

package beans;

public class SearchAd {
	private String nameOglas;
	private int minPrice;
	private int maxPrice;
	private int minLikes;
	private int maxLikes;
	private String minDate;
	private String maxDate;
	
	private String city;

	public SearchAd() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SearchAd(String nameOglas, int minPrice, int maxPrice, int minLikes, int maxLikes, String minDate,
			String maxDate, String city) {
		super();
		this.nameOglas = nameOglas;
		this.minPrice = minPrice;
		this.maxPrice = maxPrice;
		this.minLikes = minLikes;
		this.maxLikes = maxLikes;
		this.minDate = minDate;
		this.maxDate = maxDate;
		this.city = city;
	}



	public String getNameOglas() {
		return nameOglas;
	}

	public void setNameOglas(String nameOglas) {
		this.nameOglas = nameOglas;
	}

	public int getMinPrice() {
		return minPrice;
	}

	public void setMinPrice(int minPrice) {
		this.minPrice = minPrice;
	}

	public int getMaxPrice() {
		return maxPrice;
	}

	public void setMaxPrice(int maxPrice) {
		this.maxPrice = maxPrice;
	}

	public int getMinLikes() {
		return minLikes;
	}

	public void setMinLikes(int minLikes) {
		this.minLikes = minLikes;
	}

	public int getMaxLikes() {
		return maxLikes;
	}

	public void setMaxLikes(int maxLikes) {
		this.maxLikes = maxLikes;
	}

	public String getMinDate() {
		return minDate;
	}

	public void setMinDate(String minDate) {
		this.minDate = minDate;
	}

	public String getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(String maxDate) {
		this.maxDate = maxDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
}

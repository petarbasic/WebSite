package beans;

public class SearchUser {
private String ime;
private String grad;

public SearchUser() {
	super();
	// TODO Auto-generated constructor stub
}

public SearchUser(String ime, String grad) {
	super();
	this.ime = ime;
	this.grad = grad;
}

public String getIme() {
	return ime;
}

public void setIme(String ime) {
	this.ime = ime;
}

public String getGrad() {
	return grad;
}

public void setGrad(String grad) {
	this.grad = grad;
}

}

package beans;

import java.util.HashMap;
import java.util.List;

public class User {
	private String id;
	private boolean deleted;
	private String username;
	private String password;
	private String name;
	private String surname;
	private Role role;
	private String phoneNumber;
	private String city;
	private String email;
	private String date;
	//Za kupca
	private List<String> favourites;
	private List<String> ordered;
	private List<String> gotdelivered;
	//Za prodavca
	private List<String> delivered;
	private List<String> published;
	private List<Message> messages;
	private List<Message> sentmessages;
	
	private int likes;
	private int dislikes;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String id,String username, String password, String name, String surname, Role role, String phoneNumber, String city,
			String email, String date, List<String> favourites, List<String> ordered, List<String> gotdelivered, List<String> delivered,
			List<String> published, List<Message> messages, int likes, int dislikes,boolean deleted,List<Message> sentmessages) {
		super();
		this.id=id;
		this.username = username;
		this.password = password;
		this.name = name;
		this.surname = surname;
		this.role = role;
		this.phoneNumber = phoneNumber;
		this.city = city;
		this.email = email;
		this.date = date;
		this.favourites = favourites;
		this.ordered = ordered;
		this.gotdelivered = gotdelivered;
		this.delivered = delivered;
		this.published = published;
		this.messages = messages;
		this.likes = likes;
		this.dislikes = dislikes;
		this.deleted=deleted;
		this.sentmessages=sentmessages;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<String> getFavourites() {
		return favourites;
	}
	public void setFavourites(List<String> favourites) {
		this.favourites = favourites;
	}
	public List<String> getOrdered() {
		return ordered;
	}
	public void setOrdered(List<String> ordered) {
		this.ordered = ordered;
	}
	public List<String> getGotdelivered() {
		return gotdelivered;
	}
	public void setGotdelivered(List<String> gotdelivered) {
		this.gotdelivered = gotdelivered;
	}
	public List<String> getDelivered() {
		return delivered;
	}
	public void setDelivered(List<String> delivered) {
		this.delivered = delivered;
	}
	public List<String> getPublished() {
		return published;
	}
	public void setPublished(List<String> published) {
		this.published = published;
	}
	public List<Message> getMessages() {
		return messages;
	}
	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public int getDislikes() {
		return dislikes;
	}
	public void setDislikes(int dislikes) {
		this.dislikes = dislikes;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public List<Message> getSentmessages() {
		return sentmessages;
	}
	public void setSentmessages(List<Message> sentmessages) {
		this.sentmessages = sentmessages;
	}
	
}

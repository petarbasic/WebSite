package dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import beans.Ad;

public class AdsDAO {
		private HashMap<String, Ad> ads = new HashMap<>();
		private String contextPath;
		
		public AdsDAO() {
			
		}
		public AdsDAO(String contextPath) {
			loadAds(contextPath);
			this.contextPath = contextPath;
		}
		
		public void loadAds(String contextPath) {
			BufferedReader in = null;
			ObjectMapper mapper = new ObjectMapper();
			List<Ad> adFromFile = new ArrayList<>();
			try {
				File file = new File (contextPath + "/oglasi.json");
				
				in = new BufferedReader(new FileReader(file));

				if (in != null) {
					adFromFile = mapper.readValue(in, new TypeReference<List<Ad>>(){});
					ads.clear();
					
					for (Ad a : adFromFile) {
						ads.put(a.getId(), a);
					}
				} 
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (in != null)
					try {
						in.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
			}
			
		}
		
		public void saveAds() {
			ObjectMapper mapper = new ObjectMapper();
			List<Ad> adsList = new ArrayList<Ad>();
			adsList.addAll(ads.values());

			try {
				File file = new File (this.contextPath + "/oglasi.json");
				mapper.writerWithDefaultPrettyPrinter().writeValue(file , adsList);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		public List<Ad> getAll(){
			List<Ad> list = new ArrayList<>();
			for (Ad a : ads.values()) {
				if (!a.isDeleted()) {
					list.add(a);
				}
			}		
			return list;
		}
		public Ad addAd(Ad a) {
			
			Integer maxId = 0;
			for (String id : ads.keySet()) {
				int idNum =Integer.parseInt(id);
				if (idNum > maxId) {
					maxId = idNum;
				}
			}
			maxId++;
			a.setId(maxId.toString());
		//	a.setDrinks(new ArrayList<Item>());
			a.setDeleted(false);
		//	a.setMeals(new ArrayList<Item>());
			ads.put(a.getId(), a);
			

			saveAds();
			return ads.get(a.getId());
		}
		public boolean deleteAd(Ad a) {
			Ad forDelete = ads.get(a.getId());
			if(forDelete != null && !forDelete.isDeleted()) {
				forDelete.setDeleted(true);
				saveAds();
				return true;
			}else
				return false;
		}
		public Ad editAd(Ad a) {
			Ad forEdit = ads.get(a.getId());
			if (forEdit != null && !forEdit.isDeleted()) {
			
				forEdit.setName(a.getName());
				forEdit.setCity(a.getCity());
				forEdit.setPrice(a.getPrice());
				forEdit.setDescription(a.getDescription());
				forEdit.setActive(a.isActive());
				forEdit.setCategory(a.getCategory());
				forEdit.setImage(a.getImage());
				ads.put(forEdit.getId(), forEdit);
				
				saveAds();
				return forEdit;
				
			} else {
				return null;
			}
		}
		/*public Ad addItemToRest(Item item) {
			Restaurant rest = restaurants.get(item.getRestaurantId()); 
			if (rest != null) {
				if (item.getItemType() == ItemType.DRINK) {
					rest.getDrinks().add(item);
				}else
					if (item.getItemType() == ItemType.MEAL) {
						rest.getMeals().add(item);
					}
				restaurants.replace(rest.getId(), rest);
				saveRestaurants();
				return rest;
			}
			return null;
		}*/
		public Ad getById(String id) {
			Ad a = ads.containsKey(id) ? ads.get(id) : null;
			if (a != null && !a.isDeleted()) {
				return a;
			} else {
				return null;
			}
		}
		public Ad findByName(String name) {
			
			for (Ad a : ads.values()) {
				if (a.getName().equals(name)  && !a.isDeleted()) {
					return a;
				}
			}
			return null;
		}
	

}

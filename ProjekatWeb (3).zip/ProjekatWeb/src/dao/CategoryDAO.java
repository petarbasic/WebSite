package dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import beans.Ad;
import beans.Category;

public class CategoryDAO {
	private HashMap<String, Category> categories = new HashMap<>();
	private String contextPath;
	public CategoryDAO() {
	}
	public CategoryDAO(String contextPath) {
		super();
		loadCats(contextPath);
		this.contextPath = contextPath;
	}
	public void saveCats() {
		ObjectMapper mapper = new ObjectMapper();
		List<Category> adsList = new ArrayList<Category>();
		adsList.addAll(categories.values());
		

		try {
			File file = new File (this.contextPath+"/kategorije.json");
			System.out.println(file.getCanonicalPath());
			mapper.writerWithDefaultPrettyPrinter().writeValue(file , adsList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void loadCats(String contextPath) {
		BufferedReader in = null;
		ObjectMapper mapper = new ObjectMapper();
		List<Category> adFromFile = new ArrayList<>();
		try {
			File file = new File (contextPath+"/kategorije.json");
			System.out.println(file.getCanonicalPath());
			System.out.println(contextPath+"ovde");

			in = new BufferedReader(new FileReader(file));

			if (in != null) {
				adFromFile = mapper.readValue(in, new TypeReference<List<Category>>(){});
				categories.clear();
				
				for (Category c : adFromFile) {
					categories.put(c.getId(), c);
				}
			} 
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
	}
	public HashMap<String, Category> getCategories() {
		return categories;
	}
	public void setCategories(HashMap<String, Category> categories) {
		this.categories = categories;
	}
	public List<Category> getAll(){
		List<Category> list = new ArrayList<>();
		for (Category a : categories.values()) {
			if (!a.isDeleted()) {
				list.add(a);
			}
		}		
		return list;
	}
	public Category addCategory(Category c) {
		Integer maxId = 0;
		for (String id : categories.keySet()) {
			int idNum =Integer.parseInt(id);
			if (idNum > maxId) {
				maxId = idNum;
			}
		}
		maxId++;
		c.setId(maxId.toString());
		c.setDeleted(false);
		categories.put(c.getId(), c);
		saveCats();
		return categories.get(c.getId());
	}
	public boolean deleteCategory(String c) {
		Category cat=categories.get(c);
		if(cat!=null && !cat.isDeleted()) {
			cat.setDeleted(true);
			saveCats();
			return true;
		}
		
		return false;
	}
	public Category editCategory(Category c) {
		Category cat=categories.get(c.getId());
		if(cat!=null && !cat.isDeleted()) {
			cat.setDescription(c.getDescription());
			cat.setName(c.getName());
			categories.put(cat.getId(), cat);
			saveCats();
			return cat;
		}
		
		return null;
	}
	
	
}

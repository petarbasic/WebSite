package dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import beans.Ad;
import beans.Review;

public class ReviewDAO {
	private HashMap<String, Review> reviews = new HashMap<>();
	private String contextPath;
	
	public ReviewDAO() {
		
	}
	public ReviewDAO(String contextPath) {
		loadReviews(contextPath);
		this.contextPath = contextPath;
	}
	
	public void loadReviews(String contextPath) {
		BufferedReader in = null;
		ObjectMapper mapper = new ObjectMapper();
		List<Review> adFromFile = new ArrayList<>();
		try {
			File file = new File (contextPath + "/recenzije.json");
			in = new BufferedReader(new FileReader(file));

			if (in != null) {
				adFromFile = mapper.readValue(in, new TypeReference<List<Review>>(){});
				reviews.clear();
				
				for (Review a : adFromFile) {
					reviews.put(a.getId(), a);
				}
			} 
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
	}
	
	public void saveReviews() {
		ObjectMapper mapper = new ObjectMapper();
		List<Review> reviewsList = new ArrayList<Review>();
		reviewsList.addAll(reviews.values());
		

		try {
			File file = new File (this.contextPath + "/recenzije.json");
		
			mapper.writerWithDefaultPrettyPrinter().writeValue(file , reviewsList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public List<Review> getAll(){
		List<Review> list = new ArrayList<Review>();
		for (Review a : reviews.values()) {
			if (!a.isDeleted()) {
				list.add(a);
			}
		}		
		return list;
	}
	public Review addReview(Review a) {
		
		Integer maxId = 0;
		for (String id : reviews.keySet()) {
			int idNum =Integer.parseInt(id);
			if (idNum > maxId) {
				maxId = idNum;
			}
		}
		maxId++;
		a.setId(maxId.toString());
	//	a.setDrinks(new ArrayList<Item>());
		a.setDeleted(false);
	//	a.setMeals(new ArrayList<Item>());
		
		reviews.put(a.getId(), a);
		

		saveReviews();
		return reviews.get(a.getId());
	}
	
	public boolean deleteReview(Review a) {
		Review forDelete = reviews.get(a.getId());
		if(forDelete != null && !forDelete.isDeleted()) {
			forDelete.setDeleted(true);
			saveReviews();
			return true;
		}else
			return false;
	}
	public Review editreview(Review a) {
		Review forEdit = reviews.get(a.getId());
		if (forEdit != null && !forEdit.isDeleted()) {
		forEdit.setAdname(a.getAdname());
			
		forEdit.setAsagreed(a.isAsagreed());
		forEdit.setBuyerId(a.getBuyerId());
		forEdit.setContent(a.getContent());
			reviews.put(forEdit.getId(), forEdit);
			
			saveReviews();
			return forEdit;
			
		} else {
			return null;
		}
	}
	/*public Ad addItemToRest(Item item) {
		Restaurant rest = restaurants.get(item.getRestaurantId()); 
		if (rest != null) {
			if (item.getItemType() == ItemType.DRINK) {
				rest.getDrinks().add(item);
			}else
				if (item.getItemType() == ItemType.MEAL) {
					rest.getMeals().add(item);
				}
			restaurants.replace(rest.getId(), rest);
			saveRestaurants();
			return rest;
		}
		return null;
	}*/
	public Review getById(String id) {
		
		Review a = reviews.containsKey(id) ? reviews.get(id) : null;
		if (a != null && !a.isDeleted()) {
			return a;
		} else {
			return null;
		}
	}
	public Review findByName(String name) {
		
		for (Review a : reviews.values()) {
			if (a.getAdname().equals(name)  && !a.isDeleted()) {
				return a;
			}
		}
		return null;
	}
}

package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import beans.Ad;
import beans.Role;
import beans.User;

public class UserDAO {
	private HashMap<String, User> users = new HashMap<String, User>();
	private String contextPath;

	public UserDAO() {
		super();
	}

	public UserDAO(String contextPath) {
		loadUsers(contextPath);
		this.contextPath = contextPath;
	}

	public void loadUsers(String contextPath) {
		BufferedReader in = null;
		ObjectMapper mapper = new ObjectMapper();
		List<User> usersFromFile = new ArrayList<>();
		try {
			File file = new File(contextPath + "/korisnici.json");
			System.out.println(file.getCanonicalPath());
			in = new BufferedReader(new FileReader(file));

			if (in != null) {
				usersFromFile = mapper.readValue(in, new TypeReference<List<User>>() {
				});
				users.clear();

				for (User user : usersFromFile) {
					users.put(user.getId(), user);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
		}

	}

	public void saveUsers() {
		BufferedWriter out = null;
		ObjectMapper mapper = new ObjectMapper();
		List<User> userList = new ArrayList<User>();
		userList.addAll(users.values());
		System.out.println("Korisnici " + userList);

		try {
			File file = new File("C:\\Users\\Petar\\Documents\\eclipse-web\\ProjekatWeb\\WebContent\\korisnici.json");
			System.out.println(file.getCanonicalPath());

			mapper.writerWithDefaultPrettyPrinter().writeValue(file, userList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public User addUser(User user) {
		Integer maxId = 0;
		for (String id : users.keySet()) {
			int idNum = Integer.parseInt(id);
			if (idNum > maxId) {
				maxId = idNum;
			}
		}
		maxId++;
		user.setDelivered(new ArrayList<>());
		user.setFavourites(new ArrayList<>());
		user.setGotdelivered(new ArrayList<>());
		user.setMessages(new ArrayList<>());
		user.setOrdered(new ArrayList<>());
		user.setId(maxId.toString());
		users.put(user.getId(), user);
		saveUsers();
		return user;
	}

	public List<User> getAll() {

		List<User> list = new ArrayList<>();
		list.addAll(users.values());
		return list;
	}

	public User getById(String id) {
		User user = users.get(id);
		if (user != null && !user.isDeleted()) {
			return user;
		} else {
			return null;
		}

	}

	public User registerUser(User user) {
		List<User> userList = new ArrayList<>();
		userList.addAll(users.values());

		for (User u : userList) {

			if (u.getEmail().toLowerCase().equals(user.getEmail().toLowerCase())
					|| u.getUsername().toLowerCase().equals(user.getUsername().toLowerCase()))
				return null;

		}
		return addUser(user);
	}

	public User getByUsername(String username) {
		for (User user : users.values()) {

			if (user.getUsername().equals(username)) {

				return user;

			}
		}
		return null;

	}

	public User editUser(User user) {
		System.out.println(users.containsKey(user.getId()));
		User forEdit = users.containsKey(user.getId()) ? users.get(user.getId()) : null;
		if (forEdit != null) {
			forEdit.setName(user.getName());
			forEdit.setSurname(user.getSurname());
			forEdit.setRole(user.getRole());
			users.put(forEdit.getId(), forEdit);
			saveUsers();
			user.setEmail(forEdit.getEmail());
			user.setPhoneNumber(forEdit.getPhoneNumber());
			user.setUsername(forEdit.getUsername());
			user.setCity(forEdit.getCity());
			// user.setDiscountPoints(forEdit.getDiscountPoints());
			user.setDate(forEdit.getDate());
			return user;
		} else {
			return null;
		}

	}

	public boolean deleteUser(User user) {
		User forDelete = users.get(user.getId());
		if (forDelete != null && !forDelete.isDeleted()) {
			forDelete.setDeleted(true);
			saveUsers();
			return true;
		} else
			return false;
	}

	public User addToFavorite(User user, Ad a) {
		User userToAdd = users.get(user.getId());

		for (String r : userToAdd.getFavourites()) {
			if (r.equals(a.getId())) {
				return null;
			}
		}
		userToAdd.getFavourites().add(a.getId());
		saveUsers();
		return userToAdd;
	}

	public User removeFromFavorite(User user, Ad rest) {
		User userToAdd = users.get(user.getId());

		for (String r : userToAdd.getFavourites()) {
			if (r.equals(rest.getId())) {
				int index = userToAdd.getFavourites().indexOf(r);
				userToAdd.getFavourites().remove(index);
				saveUsers();
				return userToAdd;
			}
		}
		return null;
	}

	public boolean setUserOrder(User user, Ad oglas) {

		User u = getById(user.getId());
		if (u != null) {
			if (!u.getOrdered().contains(oglas.getId())) {
				u.getOrdered().add(oglas.getId());
				saveUsers();
				return true;
			}
			return false;
		}
		return false;
	}

	public User markAsDelivered(User user, Ad a) {
		User u = getById(user.getId());
		if (u != null) {
			if (u.getOrdered().contains(a.getId())) {
				u.getOrdered().remove(a.getId());
				u.getGotdelivered().add(a.getId());
				saveUsers();
				return u;
			}
			return null;
		}
		return null;
	}

	public List<User> getAdmins() {
		List<User> retval = new ArrayList<User>();
		for (User u : users.values()) {
			if (u.getRole() == Role.Admin) {
				retval.add(u);
			}
		}
		return retval;
	}

}

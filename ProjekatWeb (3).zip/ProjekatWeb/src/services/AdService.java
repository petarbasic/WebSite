package services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.fasterxml.jackson.core.type.TypeReference;

import beans.Ad;
import beans.Category;
import beans.Message;
import beans.Review;
import beans.Role;
import beans.User;
import dao.AdsDAO;
import dao.CategoryDAO;
import dao.ReviewDAO;
import dao.UserDAO;

@Path("/ads")
public class AdService {

	@Context
	ServletContext context;

	@PostConstruct
	public void init() {

		if (context.getAttribute("adsDAO") == null) {
			String contextPath = context.getRealPath("/");
			System.out.println(contextPath);
			context.setAttribute("adsDAO", new AdsDAO(contextPath));
		}
		/*
		 * if (context.getAttribute("ItemDao") == null) { String contextPath =
		 * context.getRealPath("/"); System.out.println(contextPath);
		 * context.setAttribute("ItemDao", new ItemDao(contextPath)); }
		 */
		if (context.getAttribute("userDAO") == null) {
			String contextPath = context.getRealPath("/");
			System.out.println(contextPath);
			context.setAttribute("userDAO", new UserDAO(contextPath));
		}
		if (context.getAttribute("categoryDAO") == null) {
			String contextPath = context.getRealPath("/");

			System.out.println(contextPath);
			context.setAttribute("categoryDAO", new CategoryDAO(contextPath));
		}
		if (context.getAttribute("reviewDAO") == null) {
			String contextPath = context.getRealPath("/");
			System.out.println(contextPath);
			context.setAttribute("reviewDAO", new ReviewDAO(contextPath));
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Ad> allAds(@Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");

		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		List<Ad> retval = new ArrayList<Ad>();
		retval = dao.getAll();
		if (user != null) {
			for (Ad ad : dao.getAll()) {
				for (String a : user.getOrdered()) {
					if (a.equals(ad.getId())) {
						retval.remove(ad);
					}
				}
			}
		}

		return retval;

	}

	@GET
	@Path("/allAds")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Ad> allAdsNoUser(@Context HttpServletRequest request) {
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		return dao.getAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Ad getOne(@PathParam("id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");

		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		System.out.println("Strigao id=" + id);
		Ad a = dao.getById(id);
		System.out.println("vraca =" + a);
		return a;

	}

	@GET
	@Path("/mostPopular")
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> getMostPopular(@Context HttpServletRequest request) {
		return getPopulars();

	}

	private List<String> getPopulars() {
		UserDAO users = (UserDAO) context.getAttribute("userDAO");
		HashMap<String, Integer> populars = new HashMap<String, Integer>();
		for (User u : users.getAll()) {
			for (String s : u.getFavourites()) {
				if (populars.containsKey(s)) {
					populars.replace(s, populars.get(s) + 1);
				} else {
					populars.put(s, 1);
				}
			}
		}
		List<String> retval = new ArrayList<String>();
		for (String str : sortByValue(populars).keySet()) {
			retval.add(str);
		}
		Collections.reverse(retval);
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		for (Ad a : dao.getAll()) {
			System.out.println(a.getId() + "    ID");
			if (!retval.contains(a.getId())) {
				System.out.println(retval + "    ovde");
				retval.add(a.getId());
			}
		}

		return retval;

	}

	public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {
		List<Entry<K, V>> list = new ArrayList<>(map.entrySet());
		list.sort(Entry.comparingByValue());

		Map<K, V> result = new LinkedHashMap<>();
		for (Entry<K, V> entry : list) {
			result.put(entry.getKey(), entry.getValue());
		}

		return result;
	}

	@GET
	@Path("/cats")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Category> getCategories(@Context HttpServletRequest request) {
		// User user = (User) request.getSession().getAttribute("user");

		CategoryDAO dao = (CategoryDAO) context.getAttribute("categoryDAO");
		// System.out.println("Strigao id="+id);

		return dao.getAll();

	}

	@PUT
	@Path("/add-favorite/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addFavorite(@PathParam("id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		User edited = new User();
		if (user == null || user.getRole() != Role.Kupac) {
			return Response.status(401).entity("Morate biti ulogovani.").build();
		} else {
			Ad AdToAdd = dao.getById(id);
			edited = userDao.addToFavorite(user, AdToAdd);
			if (edited == null) {
				return Response.status(400).entity("Oglas je vec dodat u listu omiljenih.").build();
			} else
				return Response.ok(AdToAdd).build();
		}
	}

	@DELETE
	@Path("/remove-favorite/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response removeFavorite(@PathParam("id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		User edited = new User();
		System.out.println(user);
		if (user == null || user.getRole() != Role.Kupac) {
			return Response.status(401).entity("Morate biti ulogovani.").build();
		} else {
			Ad AdToAdd = dao.getById(id);
			edited = userDao.removeFromFavorite(user, AdToAdd);
			if (edited == null) {
				return Response.status(400).entity("Oglas nije u listi omiljenih.").build();
			} else
				return Response.ok(AdToAdd).build();
		}
	}

	@POST
	@Path("/dodajOglas")
	@Consumes(value = { MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_JSON })
	@Produces(MediaType.APPLICATION_JSON)
	public Response addAds(@FormDataParam("fajl") InputStream fileInputStream, @FormDataParam("slika") String picName,
			@FormDataParam("Oglas") FormDataBodyPart aDtoAdd, @Context HttpServletRequest request) throws Exception {
		
		aDtoAdd.setMediaType(MediaType.APPLICATION_JSON_TYPE);
		Ad a = aDtoAdd.getValueAs(Ad.class);
		writeToFile(fileInputStream, context.getRealPath("/") + "images/" + picName);
		User user = (User) request.getSession().getAttribute("user");
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		Ad added = new Ad();
		if (a.getName().trim().isEmpty() || a.getDescription().trim().isEmpty()) {
			return Response.status(Status.BAD_REQUEST).entity("Unesite ispravne podatke.").build();
		} else {
			a.setImage(context.getContextPath() + "/images/" + picName);
			a.setSeller(user.getId());
			added = dao.addAd(a);
		}

		if (added != null) {
			return Response.ok(a).build();
		} else
			return Response.status(Status.BAD_REQUEST).entity("Drugi deo.").build();
	}

	@GET
	@Path("/testData")
	@Produces(MediaType.APPLICATION_JSON)
	public Ad addAd(@Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		Ad a = new Ad();
		a.setName("Oglas 1");
		// rest.setRestCateg(RestCateg.Domaca_kuhinja);
		// rest.setAddress("Adresa 1");
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		dao.addAd(a);
		return a;
	}

	@DELETE
	@Path("/deleteReview/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteReview(@PathParam(value = "id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");

		// rest.setRestCateg(RestCateg.Domaca_kuhinja);
		// rest.setAddress("Adresa 1");
		ReviewDAO dao = (ReviewDAO) context.getAttribute("reviewDAO");
		
		Review r = dao.getById(id);
		
		if (dao.deleteReview(r)) {
			AdsDAO AdDao = (AdsDAO) context.getAttribute("adsDAO");
			Ad oglas = null;
			for (Ad a : AdDao.getAll()) {
				for (Review rev : a.getReviews()) {
					if(rev.getId().equals(id)) {
						oglas=a;
						break;
					}
				}
				if(oglas!=null) {
					break;
				}
			}
				List<Review> rec = oglas.getReviews();
				
					for (int i = 0; i < rec.size(); i++) {
						if (rec.get(i).getId().equals(id)) {
							rec.get(i).setDeleted(true);
							return Response.status(200).build();
						}
					}
				
			}
		return Response.status(400).entity("Doslo je do greske pri brisanju").build();

	}

	@POST
	@Path("/addReview")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Review addReview(Review recenzija, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		if (user != null) {
			String bid = user.getId();
			recenzija.setBuyerId(bid);
		}
		ReviewDAO dao = (ReviewDAO) context.getAttribute("reviewDAO");
		AdsDAO AdDao = (AdsDAO) context.getAttribute("adsDAO");
		Ad oglas = AdDao.getById(recenzija.getId());
		// oglas.getReviews().add(recenzija);
		oglas.getReviews().add(dao.addReview(recenzija));
		AdDao.saveAds();
		return recenzija;
	}

	/*
	 * @POST
	 * 
	 * @Path("/search")
	 * 
	 * @Consumes(MediaType.APPLICATION_JSON)
	 * 
	 * @Produces(MediaType.APPLICATION_JSON) public SearchRestDto
	 * searchRestaurants(SearchRestDto searchRestDto, @Context HttpServletRequest
	 * request) { User user = (User) request.getSession().getAttribute("user");
	 * 
	 * String name = searchRestDto.getRestName(); String address =
	 * searchRestDto.getRestAddress(); RestCateg restCateg; if
	 * (searchRestDto.getRestCateg() >= 0) { restCateg =
	 * RestCateg.values()[searchRestDto.getRestCateg()]; }else { restCateg = null; }
	 * 
	 * System.out.println(name.isEmpty()); System.out.println(address.isEmpty());
	 * System.out.println(restCateg); if (name.isEmpty()) { name=null; } if
	 * (address.isEmpty()) { address=null; } RestaurantDao restDao = (RestaurantDao)
	 * context.getAttribute("RestaurantDao"); List<Restaurant> allRestaurants =
	 * restDao.getAll(); List<Restaurant> retList = new ArrayList<Restaurant>();
	 * List<Restaurant> restName = new ArrayList<Restaurant>(); List<Restaurant>
	 * restAddr = new ArrayList<Restaurant>(); List<Restaurant> restCategList = new
	 * ArrayList<Restaurant>(); for (Restaurant rest : allRestaurants) { if (name !=
	 * null && rest.getName().toLowerCase().contains(name.toLowerCase())) { if
	 * (!restName.contains(rest)) { restName.add(rest); } } if (address != null &&
	 * rest.getAddress().toLowerCase().contains(address.toLowerCase())) { if
	 * (!restAddr.contains(rest)) { restAddr.add(rest); } } if (restCateg != null &&
	 * rest.getRestCateg() == restCateg) { if (!restCategList.contains(rest)) {
	 * restCategList.add(rest); } }
	 * 
	 * } if(name != null && address != null && restCateg != null) { if
	 * (restName.isEmpty() || restAddr.isEmpty() || restCategList.isEmpty()) {
	 * System.out.println("ovde1"); System.out.println(restName.isEmpty());
	 * System.out.println(restAddr.isEmpty());
	 * System.out.println(restCategList.isEmpty()); return searchRestDto; }else {
	 * for (Restaurant r : restName) { if (restAddr.contains(r) &&
	 * restCategList.contains(r)) { System.out.println("ovde2"); retList.add(r); } }
	 * searchRestDto.setRestaurants(retList); return searchRestDto; } } if (name !=
	 * null && address != null && restCateg == null) { if (restName.isEmpty() ||
	 * restAddr.isEmpty()) { return searchRestDto; }else { for (Restaurant r :
	 * restName) { if (restAddr.contains(r)) { retList.add(r); } }
	 * searchRestDto.setRestaurants(retList); return searchRestDto; } } if (name !=
	 * null && address == null && restCateg != null) { if (restName.isEmpty() ||
	 * restCategList.isEmpty()) { return searchRestDto; }else { for (Restaurant r :
	 * restName) { if (restCategList.contains(r)) { retList.add(r); } }
	 * searchRestDto.setRestaurants(retList); return searchRestDto; } } if (name ==
	 * null && address != null && restCateg != null) { if (restAddr.isEmpty() ||
	 * restCategList.isEmpty()) { return searchRestDto; }else { for (Restaurant r :
	 * restAddr) { if (restCategList.contains(r)) { retList.add(r); } }
	 * searchRestDto.setRestaurants(retList); return searchRestDto; } } if (name !=
	 * null && address == null && restCateg == null) { if (restName.isEmpty()) {
	 * return searchRestDto; }else { searchRestDto.setRestaurants(restName); return
	 * searchRestDto; } } if (name == null && address != null && restCateg == null)
	 * { if (restAddr.isEmpty()) { return searchRestDto; }else {
	 * searchRestDto.setRestaurants(restAddr); return searchRestDto; } } if (name ==
	 * null && address == null && restCateg != null) { if (restCategList.isEmpty())
	 * { return searchRestDto; }else { searchRestDto.setRestaurants(restCategList);
	 * return searchRestDto; } } searchRestDto.setRestaurants(retList); return
	 * searchRestDto; }
	 */
	public List<Ad> intersect(List<Ad> list1, List<Ad> list2) {
		List<Ad> retList = new ArrayList<Ad>();

		for (Ad a : list1) {
			if (list2.remove(a)) {
				retList.add(a);
			}
		}
		return retList;
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/upload/{id}")
	public Response upload(@PathParam(value = "id") String id, InputStream fileInputStream) throws Exception {
		// here you got your file
		writeToFile(fileInputStream, context.getRealPath("/") + "images/" + id);
		ReviewDAO dao = (ReviewDAO) context.getAttribute("reviewDAO");
		List<Review> lista = dao.getAll();
		Review r = lista.get(lista.size() - 1);
		r.setImage(context.getContextPath() + "/images/" + r.getImage());
		System.out.println(r.getImage() + "image");
		dao.editreview(r);
		AdsDAO addao = (AdsDAO) context.getAttribute("adsDAO");
		addao.saveAds();
		return Response.ok(r).status(200).build();
	}

	// save uploaded file to new location
	private void writeToFile(InputStream uploadedInputStream,

			String uploadedFileLocation) {
		try {
			OutputStream out = new FileOutputStream(new File(uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@POST
	@Path("/orderProduct/{id}")
	public Response setOrder(@PathParam(value = "id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		AdsDAO AdDao = (AdsDAO) context.getAttribute("adsDAO");
		Ad oglas = AdDao.getById(id);
		if (user != null && oglas != null) {

			if (userDao.setUserOrder(user, oglas)) {
				return Response.ok().status(200).entity("Proizvod uspesno porucen!").build();
			} else {
				return Response.status(Status.NOT_FOUND).entity("Niste ulogovani").build();
			}

		}
		return Response.status(Status.NOT_FOUND)
				.entity("Doslo je do greske prilikom porucivanja proizvoda/niste ulogovani").build();
	}

	@PUT
	@Path("/markAsDelivered/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response markDelivered(@PathParam("id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		User edited = new User();
		if (user == null || user.getRole() != Role.Kupac) {
			return Response.status(401).entity("Morate biti ulogovani.").build();
		} else {
			Ad AdToAdd = dao.getById(id);
			edited = userDao.markAsDelivered(user, AdToAdd);
			if (edited == null) {
				return Response.status(400).entity("Oglas nije u listi.").build();
			} else {
				User uToRecieve = userDao.getById(AdToAdd.getSeller());
				Date dNow = new Date();
				SimpleDateFormat ft = new SimpleDateFormat("S");
				SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
				Message m = new Message(ft.format(dNow) + AdToAdd.getId(), AdToAdd.getName(), user.getId(),
						"Oglas dostavljen", "Korisnik " + user.getName() + " potvrdjuje da je proizvod "
								+ AdToAdd.getName() + " uspesno dostavljen",
						ft1.format(dNow), false);
				uToRecieve.getMessages().add(m);
				userDao.saveUsers();
				return Response.ok(AdToAdd).build();
			}
		}
	}

	@DELETE
	@Path("/deleteAd/{id}")
	public Response deleteAd(@PathParam(value = "id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		AdsDAO AdDao = (AdsDAO) context.getAttribute("adsDAO");
		Ad oglas = AdDao.getById(id);
		if (oglas != null && user.getRole() == Role.Prodavac) {
			if (user.getPublished().contains(id)) {
				user.getPublished().remove(id);
				AdDao.deleteAd(oglas);
				List<User> uToRecieve = usdao.getAdmins();
				Date dNow = new Date();
				SimpleDateFormat ft = new SimpleDateFormat("S");
				SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
				Message m = new Message(ft.format(dNow) + id, oglas.getName(), user.getId(), "Oglas izbrisan",
						"Korisnik " + user.getName() + " je obrisao oglas:  " + oglas.getName(), ft1.format(dNow),
						false);
				for (User user2 : uToRecieve) {
					user2.getMessages().add(m);
				}
				usdao.saveUsers();
				return Response.ok().status(200).build();
			}

		}
		if (oglas != null && user.getRole() == Role.Admin) {
			User prodavac = usdao.getById(oglas.getSeller());
			if (prodavac.getPublished().contains(id)) {
				prodavac.getPublished().remove(id);
				AdDao.deleteAd(oglas);
				Date dNow = new Date();
				SimpleDateFormat ft = new SimpleDateFormat("S");
				SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
				Message m = new Message(ft.format(dNow) + id, oglas.getName(), user.getId(), "Oglas izbrisan",
						"Admin " + user.getName() + " je obrisao oglas:  " + oglas.getName(), ft1.format(dNow), false);
				prodavac.getMessages().add(m);

				usdao.saveUsers();
				return Response.ok().status(200).build();
			}
		}
		return Response.status(400).build();
	}

	@POST
	@Path("/msgRead/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response messageRead(@PathParam(value = "id") String id, @Context HttpServletRequest request) {
		User u = (User) request.getSession().getAttribute("user");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		if (u != null) {
			int i = -1;
			for (Message m : u.getMessages()) {
				if (m.getId().equals(id)) {
					i = u.getMessages().indexOf(m);
					break;
				}
			}
			if (i != -1) {
				u.getMessages().get(i).setRead(true);
				String buyerId = u.getMessages().get(i).getUser();
				userDao.saveUsers();
				return Response.ok(userDao.getById(buyerId)).status(200).build();
			}
		}
		return Response.status(400).entity("Neuspesno.").build();
	}

	@POST
	@Path("/msgAnswerSend/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response messageAnswerSend(@PathParam(value = "id") String id, Message m,
			@Context HttpServletRequest request) {
		User u = (User) request.getSession().getAttribute("user");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		if (u != null) {
			User primalac = userDao.getById(id);
			if (primalac != null) {
				Date dNow = new Date();
				SimpleDateFormat ft = new SimpleDateFormat("S");
				SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
				m.setId(ft.format(dNow) + m.getId());
				m.setUser(u.getId());
				m.setDatetime(ft1.format(dNow));
				m.setRead(false);
				primalac.getMessages().add(m);
				return Response.ok().status(200).build();
			}
		}
		return Response.status(400).entity("Neuspesno.").build();
	}

	@DELETE
	@Path("/deleteMsg/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteMessage(@PathParam(value = "id") String id, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		if (user != null) {
			int i = -1;
			for (Message m : user.getMessages()) {
				if (m.getId().equals(id)) {
					i = user.getMessages().indexOf(m);
					break;
				}
			}
			if (i != -1) {
				user.getMessages().remove(i);
				userDao.saveUsers();
				return Response.ok().status(200).build();
			}
		}

		return Response.status(400).entity("Doslo je do greske pri brisanju").build();
	}

	@POST
	@Path("/changeAd")
	@Consumes(value = { MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_JSON })
	@Produces(MediaType.APPLICATION_JSON)
	public Response changeAd(@FormDataParam("fajl") InputStream fileInputStream, @FormDataParam("slika") String picName,
			@FormDataParam("Oglas") FormDataBodyPart aDtoAdd, @Context HttpServletRequest request) {
		aDtoAdd.setMediaType(MediaType.APPLICATION_JSON_TYPE);
		Ad zaIzmenu = aDtoAdd.getValueAs(Ad.class);
		zaIzmenu.setImage(context.getContextPath() + "/images/" + picName);
		writeToFile(fileInputStream, context.getRealPath("/") + "images/" + picName);
		User user = (User) request.getSession().getAttribute("user");
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		AdsDAO AdDao = (AdsDAO) context.getAttribute("adsDAO");
		if (user != null) {
			if (user.getRole() == Role.Prodavac) {
				if (AdDao.editAd(zaIzmenu) != null) {
					return Response.ok().status(200).build();
				}
			} else if (user.getRole() == Role.Admin) {

				if (AdDao.editAd(zaIzmenu) != null) {
					Date dNow = new Date();
					SimpleDateFormat ft = new SimpleDateFormat("S");
					SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
					Message m = new Message(ft.format(dNow) + zaIzmenu.getId(), zaIzmenu.getName(), user.getId(),
							"Oglas izmenjen", "Admin " + user.getName() + " je izmenio oglas:  " + zaIzmenu.getName(),
							ft1.format(dNow), false);
					usdao.getById(zaIzmenu.getSeller()).getMessages().add(m);
					return Response.ok().status(200).build();
				}

			}
		}
		return Response.status(400).entity("Doslo je do greske pri izmeni oglasa").build();
	}

}
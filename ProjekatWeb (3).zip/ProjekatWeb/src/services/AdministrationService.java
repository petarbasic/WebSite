package services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import beans.Ad;
import beans.Category;
import beans.Message;
import beans.Review;
import beans.Role;
import beans.SearchAd;
import beans.SearchUser;
import beans.User;
import dao.AdsDAO;
import dao.CategoryDAO;
import dao.ReviewDAO;
import dao.UserDAO;

@Path("/admin")
public class AdministrationService {
	@Context
	ServletContext context;
	
	@GET
	@Path("/allUsers")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getAllUsers(@Context HttpServletRequest request){
		User user = (User) request.getSession().getAttribute("user");
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		if(user.getRole()==Role.Admin) {
			return usdao.getAll();
		}else {
			return null;
		}
	}
	@POST
	@Path("/changeCat")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response changeCategory(Category cat,@Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		CategoryDAO dao = (CategoryDAO) context.getAttribute("categoryDAO");
		if(cat!=null) {
			if(dao.editCategory(cat)!=null && user.getRole()==Role.Admin) {
				return Response.ok().status(200).build();
			}
		}
		return Response.status(400).build();
	}
	@POST
	@Path("/changeUser/{id}")
	@Consumes(MediaType.TEXT_HTML)
	public Response changeUser(@PathParam(value="id")String id,String uloga,@Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		UserDAO dao = (UserDAO) context.getAttribute("userDAO");
		if(dao.getById(id)!=null && user.getRole()==Role.Admin) {
				if(!uloga.equals("Kupac")) {
					dao.getById(id).setRole(uloga.equals("Prodavac")?Role.Prodavac:Role.Admin);
				}else {
					dao.getById(id).setRole(Role.Kupac);
				}
				
				dao.saveUsers();
				return Response.ok().status(200).build();
		}
		return Response.status(400).build();
	}
	@POST
	@Path("/addCat")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response AddCategory(Category cat,@Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		CategoryDAO dao = (CategoryDAO) context.getAttribute("categoryDAO");
		if(cat!=null) {
			if(dao.addCategory(cat)!=null && user.getRole()==Role.Admin) {
				return Response.ok().status(200).build();
			}
		}
		return Response.status(400).build();
	}
	@DELETE
	@Path("/deleteCategory/{id}")
	public Response deleteCategory(@PathParam(value="id")String id,@Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		CategoryDAO dao = (CategoryDAO) context.getAttribute("categoryDAO");
			if(dao.deleteCategory(id) && user.getRole()==Role.Admin) {
				return Response.ok().status(200).build();
			}
		
		return Response.status(400).build();
	}
	@POST
	@Path("/getSearchUsers")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getSearchUsers(SearchUser searchParams,@Context HttpServletRequest request){
		
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		List<User> retval = new ArrayList<User>();
		if(searchParams!=null && usdao!=null) {
		for (User u : usdao.getAll()) {
			if(!u.getName().toLowerCase().trim().contains(searchParams.getIme().toLowerCase().trim()) && !searchParams.getIme().trim().isEmpty()) {
				continue;
			}
			if(!u.getCity().trim().equals(searchParams.getGrad().trim())&& !searchParams.getGrad().trim().isEmpty()) {
				continue;
			}
			retval.add(u);
		}
		return Response.ok(retval).status(200).build();
		}else {
			System.out.println("NE RADI");
			return Response.status(400).build();
		}
		
	}
	@POST
	@Path("/searchAds")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getSearchAds(SearchAd searchParams,@Context HttpServletRequest request){
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		
		List<Ad> retval = new ArrayList<Ad>();

		if(searchParams!=null && dao!=null) {
		for (Ad a : dao.getAll()) {
			if(!a.getName().toLowerCase().trim().contains(searchParams.getNameOglas().toLowerCase().trim()) && !searchParams.getNameOglas().equals("")) {
				continue;
			}
			if(!a.getCity().equals(searchParams.getCity()) && !searchParams.getCity().equals("")) {
				continue;
			}
			if((a.getPrice()>searchParams.getMaxPrice() || a.getPrice()<searchParams.getMinPrice()) &&  searchParams.getMaxPrice()!=0 ) {
				continue;
			}
			if((a.getLikes()>searchParams.getMaxLikes() || a.getLikes()<searchParams.getMinLikes()) &&  searchParams.getMinLikes()!=0 ) {
				continue;
			}
			retval.add(a);
		}
		return Response.ok(retval).status(200).build();
		}else {
			return Response.status(401).build();
		}
		
	}
	
	@GET
	@Path("/getCities")
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> getGradovi(){
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		List<String> retval = new ArrayList<String>();
		for (Ad a : dao.getAll()) {
			if(!retval.contains(a.getCity())) {
				retval.add(a.getCity());
			}
			
		}
		return retval;
	}
	@POST
	@Path("/addLike/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addLike(@PathParam(value="id")String id){
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		dao.getById(id).setLikes(dao.getById(id).getLikes()+1);
		dao.saveAds();
		usdao.getById(dao.getById(id).getSeller()).setLikes(usdao.getById(dao.getById(id).getSeller()).getLikes()+1);
		return Response.status(200).build();
	}
	@POST
	@Path("/addDisLike/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addDisLike(@PathParam(value="id")String id){
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		dao.getById(id).setDislikes(dao.getById(id).getDislikes()+1);
		dao.saveAds();
		usdao.getById(dao.getById(id).getSeller()).setDislikes(usdao.getById(dao.getById(id).getSeller()).getDislikes()+1);
		return Response.status(200).build();
	}
	@GET
	@Path("/reportAd/{id}")
	public Response reportAd(@PathParam(value="id")String id,@Context HttpServletRequest request) {
		UserDAO usdao = (UserDAO) context.getAttribute("userDAO");
		AdsDAO dao = (AdsDAO) context.getAttribute("adsDAO");
		User u = (User) request.getSession().getAttribute("user");
		if(u!=null) {
			for (User us : usdao.getAll()) {
				if(us.getRole()==Role.Admin) {
					Date dNow = new Date();
					SimpleDateFormat ft = new SimpleDateFormat("S");
					SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
					Message m = new Message(ft.format(dNow) + dao.getById(id).getId(), dao.getById(id).getName(), u.getId(),
							"Prijava oglasa", "Korisnik " + u.getName() + " prijavljuje proizvod "
									+ dao.getById(id).getName() + " uspesno dostavljen",
							ft1.format(dNow), false);
					us.getMessages().add(m);
					
					return Response.status(200).build();
				}
			}
		}

		return Response.status(400).build();
	}
	@POST
	@Path("/changeReview")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response changeReview(Review recenzija, @Context HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		if (user != null) {
			ReviewDAO dao = (ReviewDAO) context.getAttribute("reviewDAO");
			Review izmena=dao.editreview(recenzija);
			AdsDAO AdDao = (AdsDAO) context.getAttribute("adsDAO");
			Ad oglas = null;
			for (Ad a : AdDao.getAll()) {
				for (Review rev : a.getReviews()) {
					if(rev.getId().equals(recenzija.getId())) {
						oglas=a;
						break;
					}
				}
				if(oglas!=null) {
					break;
				}
			}
				List<Review> rec = oglas.getReviews();
				
					for (int i = 0; i < rec.size(); i++) {
						if (rec.get(i).getId().equals(recenzija.getId())) {
							rec.get(i).setAdname(izmena.getAdname());
							rec.get(i).setTitle(izmena.getTitle());
							rec.get(i).setContent(izmena.getContent());
							rec.get(i).setAsagreed(izmena.isAsagreed());
							rec.get(i).setDesctrue(izmena.isDesctrue());
							return Response.status(200).build();
						}
					}
		}
		
		return Response.status(400).build();
	}
	@POST
	@Path("/msgAdminSend/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response messageAnswerSend(@PathParam(value = "id") String id, Message m,
			@Context HttpServletRequest request) {
		User u = (User) request.getSession().getAttribute("user");
		UserDAO userDao = (UserDAO) context.getAttribute("userDAO");
		if (u != null) {
			User primalac = userDao.getById(id);
			if (primalac != null) {
				Date dNow = new Date();
				SimpleDateFormat ft = new SimpleDateFormat("S");
				SimpleDateFormat ft1 = new SimpleDateFormat("dd.MM.yyyy ',' hh:mm:ss");
				m.setId(ft.format(dNow) + m.getId());
				m.setUser(u.getId());
				m.setDatetime(ft1.format(dNow));
				m.setRead(false);
				primalac.getMessages().add(m);
				return Response.ok().status(200).build();
			}
		}
		return Response.status(400).entity("Neuspesno.").build();
	}
}

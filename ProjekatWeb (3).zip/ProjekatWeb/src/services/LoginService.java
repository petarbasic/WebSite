package services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import beans.Role;
import beans.User;
import dao.UserDAO;



@Path("")
public class LoginService {
	
	@Context
	ServletContext ctx;
	
	public LoginService() {
		
	}
	
	@PostConstruct
	// ctx polje je null u konstruktoru, mora se pozvati nakon konstruktora (@PostConstruct anotacija)
	public void init() {
		// Ovaj objekat se instancira vi�e puta u toku rada aplikacije
		// Inicijalizacija treba da se obavi samo jednom
		if (ctx.getAttribute("userDAO") == null) {
	    	String contextPath = ctx.getRealPath("/");
			ctx.setAttribute("userDAO", new UserDAO(contextPath));
		}
	}
	
	@POST
	@Path("/login")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response login(User user, @Context HttpServletRequest request) {
		User loggedUser=null;// = buyerDao.find(user.getUsername(), user.getPassword());
		HttpSession session = request.getSession();
		if (session.getAttribute("user") != null) {
			
			return Response.status(400).entity("Vec ste prijavljeni.").build();
		}
		if (user.getUsername().trim().isEmpty() || user.getPassword().trim().isEmpty() ) {
			return Response.status(400).entity("Unesite ispravno korisnicko ime i lozinku.").build();
		}
		UserDAO dao = (UserDAO) ctx.getAttribute("userDAO");
		User newUser = dao.getByUsername(user.getUsername());
		if (newUser != null && newUser.getPassword().equals(user.getPassword())) {
			session.setAttribute("user", newUser);
			//return Response.status(200).entity("Uspesno ste se prijavili.").build();
			User retUser = new User();
			retUser.setUsername(newUser.getUsername());
			retUser.setName(newUser.getName());
			retUser.setRole(newUser.getRole());
			return Response.ok(retUser).status(200).build();
			
		} else {
			
			return Response.status(400).entity("Neispravno korisnicko ime i/ili lozinka.").build();
		}
	}
	@POST
	@Path("/registration")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response registracija(User user) {
		user.setRole(Role.Kupac);

		//SimpleDateFormat sdf = new SimpleDateFormat("dd/M/yyyy HH:mm");
		DateFormat dateFormat = new SimpleDateFormat("dd/M/yyyy");
		String date = dateFormat.format(new Date());
		user.setDate(date);
		
		System.out.println("Datum string" + date);
		if (user.getName().trim().isEmpty() || user.getSurname().trim().isEmpty() || user.getEmail().isEmpty() || user.getPassword().isEmpty() || user.getPhoneNumber().isEmpty()) {
			return Response.status(400).entity("Popunite polja za registraciju.").build();

		}
		UserDAO dao = (UserDAO) ctx.getAttribute("userDAO");
		User newUser = dao.registerUser(user);
		
		if (newUser == null) {
			
			return Response.status(400).entity("Korisnicko ime ili email vec postoje.").build();
		
		}else 
			
			return Response.status(200).build();
		
		
		
	}
	
	@POST
	@Path("/logout")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void logout(@Context HttpServletRequest request) {
		request.getSession().invalidate();
	}
	
	@GET
	@Path("/currentUser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User login(@Context HttpServletRequest request) {
		return (User) request.getSession().getAttribute("user");
	}
}

/**
 * 
 **/
var userLogged = 'none';
$(document).ready(function () {
	$("#formaPrijava").submit(funPrijava());
	isLoggedIn();
	//Submit prijave
	function funPrijava() {
		return function (event) {
			event.preventDefault();
			$('#errorLog').text('');
			let username = $('input[name="inputPrijavaKorIme"]').val();
			let password = $('input[name="inputPrijavaLozinka"]').val();
			$.post({
				url: 'rest/login',
				data: JSON.stringify({ username: username, password: password }),
				contentType: 'application/json',
				success: function (data) {
					showAlertModal('Uspesno ste se prijavili.');

					$('#modalPrijava').modal('toggle');
					/*if ($('#modalPonuda').find('h3').text() !== '' && data.role == 'Kupac') {
						$('#modalPonuda').modal('toggle');
					}else{
						isLoggedIn();
					}*/
					isLoggedIn();
					$('#btnPrijava').hide();
					$('#btnReg').hide();
					$('#btnLogout').show();
					$('#btnUserName').text(data.name);
					$('#userbtnGroup').show();
					$('#userbtnGroup').find("#btnUserName").unbind();
					$('#userbtnGroup').find("#btnUserName").click(showUserPage());

				}, error: function (message) {
					showAlertModal(message.responseText);
					//alert(message.responseText);
					$('#errorLog').text(message.responseText);
					$('#errorLog').show();
					$('#errorLog').delay(4000).fadeOut('slow');
				}
			});
		}
	}
	//Najpopularniji
	function getNajpopularniji(divs) {
		$.get({
			url: "rest/ads/mostPopular",
			success: function (data) {
				divs.hide();
				let breaks = $(".w-100");
				breaks.remove();
				let duz = data.length > 3 ? 3 : data.length;
				for (j = 0; j < data.length; j++) {
					divs.get().forEach((element, i) => {
						if (element.id == ("card" + data[j])) {
							duz--;
							divs.eq(i).show();
							if (duz == 0) {
								return;
							}
						}
					});
					if (duz == 0) {
						break;
					}
				}


			}
		});
	}
	//Submit registracije
	$('form#formaRegistracija').submit(function (event) {
		event.preventDefault();
		let name = $('input[name="inputIme"]').val();
		let surname = $('input[name="inputPrezime"]').val();
		let phoneNumber = $('input[name="inputTelefon"]').val();
		let email = $('input[name="inputEmail"]').val();
		let username = $('input[name="inputKorIme"]').val();
		let password = $('input[name="inputLozinka"]').val();
		let city = $('input[name="inputCity"]').val();

		userData = JSON.stringify({
			name: name,
			surname: surname,
			phoneNumber: phoneNumber,
			email: email,
			username: username,
			password: password,
			city: city
		});
		$('#error').hide();
		$.post({
			url: 'rest/registration',
			data: userData,
			contentType: 'application/json',
			success: function (data) {
				alert('Uspesno ste se registrovali.');
				$('#modalRegistracija').modal('toggle');
			}, error: function (message) {
				$('#errorReg').text(message.responseText);
				$('#errorReg').show();
				$('#errorReg').delay(5000).fadeOut('slow');
			}
		});
	});
	//Ucitavanje kategorija
	function getAdCategory(data, i) {
		let rest = '<a class="nav-link categFilter tab" id="' + data.name + '" data-toggle="pill" href="#" role="tab"  aria-selected="false">' + data.name + '</a>';
		return rest;
	}
	function getCategories(user) {
		$.ajax({
			url: "rest/ads/cats"
		}).then(function (data) {

			console.log(data);
			$('#v-pills-tab').empty();
			$('#v-pills-tab').append(' <a class="nav-link categFilter active" id="mostPopular" data-toggle="pill" href="#v-pills-home" role="tab"'
				+ 'aria-controls="v-pills-home" aria-selected="true">Najpopularniji</a>'
				+ '<a class="nav-link categFilter " id="allCateg" data-toggle="pill" href="#v-pills-home" role="tab"'
				+ 'aria-controls="v-pills-home" aria-selected="true">Svi Oglasi</a>'
				+ '<a class="nav-link " data-toggle="pill" role="tab">Kategorije:</a>');

			for (var i = 0; i < data.length; i++) {
				if (data[i] !== null) {
					$('#v-pills-tab').append(getAdCategory(data[i], i));
					continue;
				}

			}

			$('#v-pills-tab').append('<br><button id="navBtnAddCat" style="display: none; text-align:left;" type="button" class="btn btn-outline-primary btn-sm mx-2"  >'
				+ 'Dodaj kategoriju'
				+ '</button>');
			getAds(user);

		});
	}
	//Filter-prikaz po kategorijama
	function addListenerFilter() {
		$(".categFilter").on('click', function () {
			$('#v-pills-tab').find('.active').removeClass('active')
			$(this).addClass('active');
			var filter = $(this).attr('id');
			let breaks = $(".w-100");
			breaks.remove();
			divs = $("#sviOglasi").children();
			if (filter == 'allCateg') {
				for (i = 0; i < divs.length; i++) {
					divs.eq(i).show();
					if ((1 + i) % 3 == 0) {
						$('<div class="w-100" id="break' + i + '"></div> <br class="w-100">').insertAfter(divs.eq(i));
					}
				}
				return;
			}
			if (filter == 'mostPopular') {
				getNajpopularniji(divs);
				return;
			}
			filter = filter.includes('_') ? filter.replace("_", " ") : filter;
			divs.hide();
			let brojac = 0;
			for (i = 0; i < divs.length; i++) {
				name = divs.eq(i).find(".adCategory").text();
				if (name.indexOf(filter) > -1) {
					divs.eq(i).show();
					if ((1 + brojac) % 3 == 0) {
						$('<div class="w-100" id="break' + brojac + '"></div> <br class="w-100">').insertAfter(divs.eq(i));
					}
					brojac++;
				}
			}
		});
	}
	function loggedInCkeck() {
		$.get({
			url: "rest/currentUser",
			success: function (user) {
				if (user == null) {
					userLogged = 'none';
					currentUser = null;
				} else {
					userLogged = user.role;
					currentUser = user;
				}

			}
		});
	}
	//Kacenje funkcije za logout na dugme
	$('#btnLogout').click(function () {
		$.post({
			url: "rest/logout",
			success: function () {
				userLogged = 'none';
				isLoggedIn();
				$("#UserDeo").find("#userPorudzbine").find("table").find("tbody#userOrdersTable").empty();
				$("#UserDeo").find("#userDostavljeniProizvodi").find("table").find("tbody#userDeliveredTable").empty();
				$("#UserDeo").find("#userOmiljeniOglasi").find("table").find("tbody#UserFavouriteAds").empty();
				$('#btnPrijava').show();
				$('#btnReg').show();
				$('#btnLogout').hide();
				$('#userbtnGroup').hide();
				$("#pocetnaLink").click();
				showAlertModal("Uspesno ste se odjavili!");
			}
		});
	});
	//Provera login-a
	function isLoggedIn() {
		$.get({
			url: "rest/currentUser",
			success: function (user) {

				if (user == null) {
					$('#btnPrijava').show();
					$('#btnReg').show();
					$('#btnLogout').hide();
					$('#navBtnAddCat').hide();
					$('#userbtnGroup').hide();
					userLogged = 'none';
					currentUser = null;
				} else {
					if (user.role == "Kupac") {
						userLogged = user.role;
						$('#btnPrijava').hide();
						$('#btnReg').hide();
						$('#btnLogout').show();
						$('#userbtnGroup').show();
						$('#btnUserName').text(user.name);
						$('#userbtnGroup').find("#btnUserName").unbind();
						$('#userbtnGroup').find("#btnUserName").click(showUserPage());
					} else
						if (user.role == "Prodavac") {
							userLogged = user.role;
							$('#btnPrijava').hide();
							$('#btnReg').hide();
							$('#btnLogout').show();
							$('#userbtnGroup').show();
							$('#btnUserName').text(user.name);
							$('#userbtnGroup').find("#btnUserName").unbind();
							$('#userbtnGroup').find("#btnUserName").click(showUserPage());
						} else
							if (user.role == "Admin") {
								userLogged = user.role;
								$('#btnPrijava').hide();
								$('#btnReg').hide();
								$('#btnLogout').show();
								$('#userbtnGroup').show();
								$('#btnUserName').text(user.name);
								$('#userbtnGroup').find("#btnUserName").unbind();
								$('#userbtnGroup').find("#btnUserName").click(showUserPage());
							}
					$('#navBtnPrijava').hide();
					$('#navBtnReg').hide();
					$('#navBtnOdjava').show();
					$('#userbtnGroup').show();
					$('#btnUserName').text(user.name);
					currentUser = user;
				}
				getCategories(user);
			}
		});
	}
	//Pravljenje kartice za svaki oglas
	function getAdCard(data, i) {
		//var restCateg = categ.includes('_')?categ.replace("_", " "):categ;
		let rest = ' <div class="col-sm" id="card' + data.id + '">'
			+ '<div class="card bg-light  mb-3 text-center" style="width: 18rem; height: 26rem;">'
			+ '  <div class="card-header border-success text-center"><b>'
			+ data.name
			+ ' </b></div>'

			+ ' <img src="' + data.image + '" onerror="this.src = \'images/no-image.jpg\';"  class="card-img-top " style="width: 16rem; height: 20rem;" alt="...">'
			+ '<div class="card-body text-left">'
			+ ' <h5 class="card-title">Cena: ' + data.price + 'RSD</h5>'
			+ '<p class="card-text"> ' + data.description + '</p>'
			+ '<span class="adCategory" hidden="true">' + data.category + '</span>'

			+ ' </div>'
			+ '<div class="card-footer border-success text-center">'
			+ '<a href="#" id="pogledajOglas' + data.id + '" class="btn btn-primary btn-lg">Pogledaj oglas</a>'
			+ ' </div>'
			+ ' </div>'
			+ '</div>';
		if ((i + 1) % 3 === 0) {
			rest += '<div class="w-100" id="break' + i + '"></div>'
				+ ' <br class="w-100">';
		}

		return rest;
	}
	//Pribavljanje recenzija za otvoreni oglas
	function getReviews(data) {

		let retval = "";

		for (var i = 0; i < data.length; i++) {
			let button = '';
			if (!data[i].deleted) {
				if (currentUser != null) {
					if (data[i].buyerId == currentUser.id) {
						button = '<div class="containter"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownReviews" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'
						+ 'Opcije'
						+ ' </a>'
						+ '<div class="dropdown-menu" aria-labelledby="navbarDropdownReviews">'
							+ '<a class="dropdown-item" id="btnDeleteReview' + data[i].id + '" href="#">Obrisi recenziju</a>'
							+ '<a class="dropdown-item" id="btnIzmeniRecenziju' + data[i].id + '"  href="#">Izmeni recenziju</a>'
							+ '</div></div>';

					} else {
						button = '';
					}
				}

				let opis = data[i].desctrue ? "DA" : "NE";
				let dog = data[i].asagreed ? "DA" : "NE";
				let src = data[i].image == null ? '' : data[i].image;
				retval = '<li class="list-group-item" id="listItemReview' + data[i].id + '">'
					+ '<div class="card mb-3 border-info" style="max-height: 150px;">'
					+ '<div class="row no-gutters">'
					+ '<div class="col-md-2">'
					+ '<img src="' + src + '" onerror="this.src = \'images/no-image.jpg\';" class="card-img review" alt="...">'
					+ '</div>'
					+ '<div class="col-md-4">'
					+ '<div class="card-body bg-light">'
					+ '<h5 class="card-title">' + data[i].title + '</h5>'
					+ ' <p class="card-text">Opis iz oglasa tacan:  <b>' + opis + '</b></p>'
					+ ' <p class="card-text">Dogovor ispostovan:  <b>' + dog + '</b></p>'
					+ '</div>'
					+ '</div>'
					+ '<div class="col-md-3">'
					+ '<div class="card-body ">'
					+ '<h6 class="card-title" id="">Korisnik ' + data[i].buyerId + ' kaze:</h6>'
					+ ' <p class="card-text text-info">' + data[i].content + '</p>'
					+ '</div>'
					+ '</div>'
					+ '<div class="col-md-3">'
					+ '<div class="card-body ">'
				
					+ button
					+ '</div>'
					+ '</div>'
					+ '</div>'
					+ '</div>'
					+ '</li>';
				$('#oglasModal').find('#listaRecenzija').append(retval);
				let btnid = data[i].id;
				if (button != '') {
					$('#oglasModal').find('#listaRecenzija').find('#btnDeleteReview' + btnid).unbind();
					$('#oglasModal').find('#listaRecenzija').find('#btnDeleteReview' + btnid).click(deleteReview(btnid));
					$('#oglasModal').find('#listaRecenzija').find('#btnIzmeniRecenziju' + btnid).unbind();
					$('#oglasModal').find('#listaRecenzija').find('#btnIzmeniRecenziju' + btnid).click(changeReview(data[i]));
				}

			}

		}
		return retval;
	}
	function deleteReview(btnid) {
		return function () {
			$.ajax({
				url: "rest/ads/deleteReview/" + btnid+"/",
				type: "delete",

				success: function () {
					$('#oglasModal').find('#listItemReview' + btnid).remove();
					showAlertModal("Recenzija uspesno uklonjena");
				},
				error:function(){
					showAlertModal("neuspesno uklanjanje recenzije");
				}
			});
		}
	}
	function changeReview(re){
		return function () {
			$("#inputNaslovRecenzije").val(re.title);
			$("#inputSadrzajRecenzije").val(re.content);
			$("#DescTrueCheck").prop('checked', re.desctrue);
			$("#AsAgreedCheck").prop('checked', re.asagreed);
			$("#formaRecenzija").unbind();
			$("#formaRecenzija").submit(changeReview(re.id));
		}
	}
	//Klik na dugme poruci
	function setOrder(id) {
		return function () {

			$.post({
				url: "rest/ads/orderProduct/" + id,
				success: function (msg) {
					showAlertModal(msg.responseText);
					$('#oglasModal').modal('toggle');
					isLoggedIn();
				},
				error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}
	}
	//klik na dugme za prikaz oglasa
	function getAdButton(data) {
		return function () {
			$('#oglasModal').modal('toggle');
			$('#oglasModal').find('h5').text(data.name);
			$('#oglasModal').find('img').attr('src', data.image);
			$('#oglasModal').find('#dislikeNumber').text(data.dislikes);
			$('#oglasModal').find('#likeNumber').text(data.likes);
			$('#oglasModal').find('#adPrice').html("<b>Cena:</b> " + data.price);
			$('#oglasModal').find('#adCity').html("<b>Grad:</b> " + data.city);
			$('#oglasModal').find('#datumPostavljanja').html("<b>Datum postavljanja:</b> " + data.begindate);
			$('#oglasModal').find('#datumIsticanja').html("<b>Datum isticanja:</b> " + data.enddate);
			$('#oglasModal').find('#adDescription').html("<b>Opis:</b> <br>" + data.description);
			$('#oglasModal').find('#DodajOglasUOmiljene').html(' <button type="button" class="btn btn-primary" id="btnDodajOglasOmiljene">Dodaj u omiljene</button>');
			$('#oglasModal').find('#listaRecenzija').html('');
			$('#oglasModal').find("#btnLikeGreen").unbind();
			$('#oglasModal').find("#btnLikeGreen").click(function () {
				if (userLogged != 'none') {
					$.post({
						url: "rest/admin/addLike/" + data.id,
						success: function () {
							let num =$('#oglasModal').find('#likeNumber').text();
							$('#oglasModal').find('#likeNumber').text(Number.parseInt(num)+1);
						}
					});
				}

			});
			$('#oglasModal').find("#btnDisLikeGreen").unbind();
			$('#oglasModal').find("#btnDisLikeGreen").click(function () {
				if (userLogged != 'none') {
					$.post({
						url: "rest/admin/addDisLike/" + data.id,
						success: function () {
							let num=$('#oglasModal').find('#dislikeNumber').text();
							$('#oglasModal').find('#dislikeNumber').text(Number.parseInt(num)+1);
							
						}
					});
				}
			});
			getReviews(data.reviews);
			$('#oglasModal').find('#oglasAktivan').text(data.active ? 'Aktivan' : 'Neaktivan');
			$('#oglasModal').find('#btnPoruci').unbind();
			$('#oglasModal').find('#btnPoruci').click(setOrder(data.id));
			$('#formaRecenzija').hide();
			$('#btnOstaviRecenziju').unbind();
			$('#btnOstaviRecenziju').click(function (data) {
				loggedInCkeck();
				if (userLogged == 'Kupac') {
					$('#formaRecenzija').show();
				} else {
					showAlertModal("Morate biti ulogovani kao kupac!");
					$('#formaRecenzija').hide();
				}
			});
			let idAd = data.id;
			$('#oglasModal').find('#btnDodajOglasOmiljene').click(addToFavourites(data.id));
			$("#formaRecenzija").unbind();
			$("#formaRecenzija").submit(addreview(idAd));
		}
	}
	function addreview(idAd) {
		return function () {
			event.preventDefault();
			let objFile = $("#slikaRecenzija");
			let file = objFile[0].files[0];
			let fileName = file == undefined ? '' : file.name;


			document.get
			$.post({
				url: 'rest/ads/addReview',
				contentType: "application/json",
				data: JSON.stringify({
					adname: $('#modalOglasTitle').text(),
					id: idAd,
					buyerId: "",
					title: $("#inputNaslovRecenzije").val(),
					content: $("#inputSadrzajRecenzije").val(),
					image: fileName,
					desctrue: $("#DescTrueCheck").is(":checked"),
					asagreed: $("#AsAgreedCheck").is(":checked"),
					deleted: false
				}),
				success: function (data) {
					let niz = [data];
					console.log(fileName);
					if (fileName != '') {
						$.post({
							url: "rest/ads/upload/" + fileName,
							contentType: "multipart/form-data",
							data: file,
							processData: false,
							success: function (data1) {
								let niz2 = [data1];
								getReviews(niz2);
								getAds(userLogged);
							}
						});
					} else {
						getReviews(niz);
						getAds(userLogged);
					}
					$('#formaRecenzija').trigger('reset').hide();

				}
			});
		}
	}
	function sendChangedReview(idAd){
		return function(e){
			e.preventDefault();
			$.post({
				url: 'rest/admin/changeReview',
				contentType: "application/json",
				data: JSON.stringify({
					adname: $('#modalOglasTitle').text(),
					id: idAd.id,
					buyerId: idAd.buyerId,
					title: $("#inputNaslovRecenzije").val(),
					content: $("#inputSadrzajRecenzije").val(),
					image: '',
					desctrue: $("#DescTrueCheck").is(":checked"),
					asagreed: $("#AsAgreedCheck").is(":checked"),
					deleted: false
				}),
				success: function (data) {
					$("#formaRecenzija").unbind();
					$("#formaRecenzija").find("#button .btn").text("Postavi recenziju");
			$("#formaRecenzija").submit(addreview(idAd));
					$('#formaRecenzija').trigger('reset').hide();
					showAlertModal("Izmena recenzije uspesna");
				},error:function(){
					showAlertModal("Nuspesna izmena recenzije");
				}
			});
		}
		
	}
	function changeReview(idAd) {
		return function () {
			$("#formaRecenzija").show();
			$("#inputNaslovRecenzije").val(idAd.title);
			$("#inputSadrzajRecenzije").val(idAd.content);
			$("#AsAgreedCheck").prop('checked',idAd.asagreed);
			$("#DescTrueCheck").prop('checked',idAd.desctrue);
			$("#formaRecenzija").find("#button .btn").text("Izmeni recenziju");
			$("#formaRecenzija").unbind();
			$("#formaRecenzija").submit(sendChangedReview(idAd));
		}
	}
	//Dobavljanje svih oglasa
	function getAds(user) {
		let userFavorites = [];
		if (user != null && user.role == 'Kupac') {
			/*for (var i = 0; i < user.favoriteRest.length; i++) {
				userFavorites.push( user.favoriteRest[i].id);
			}*/

		}
		$.ajax({
			url: "rest/ads"
		}).then(function (data) {
			$('#sviOglasi').empty();
			console.log(data);
			for (var i = 0; i < data.length; i++) {
				if (data[i] !== null) {
					if (user == null || userLogged == 'Kupac' || userLogged == 'Prodavac' || userLogged == 'Admin') {
						let zaAppend = getAdCard(data[i], i);
						$('#sviOglasi').append(zaAppend);
						$("#pogledajOglas" + data[i].id).unbind();
						$("#pogledajOglas" + data[i].id).click(getAdButton(data[i]));
						continue;
					}
				}
			}
			addListenerFilter();
			document.getElementById('mostPopular').click();
		});


	}
	//Dugme dodaj u omiljene
	function addToFavourites(ad) {
		return function () {
			$.ajax({
				type: "put",
				url: "rest/ads/add-favorite/" + ad,
				success: function () {
					showAlertModal("Oglas dodat u listu omiljenih");
				},
				error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}
	}
	//Univerzalni prikaz poruka
	function showAlertModal(message) {

		$('#alertModal').find("#alertMessage").text(message);
		$('#alertModal').modal('toggle');
		setTimeout(function () {
			$('#alertModal').modal('toggle');

		}, 1500);
	}
	//Prikaz personalne stranice korisnika
	function showUserPage() {
		return function () {
			$.get({
				url: "rest/currentUser",
				success: function (user) {
					if (user == null) {

					} else {
						if (user.role == "Kupac") {
							$("#glavniDeoZajednicki").hide();
							$("#SellerDeo").hide();
							$("#AdminDeo").hide();
							fillUserData(user);
							$("#UserDeo").show();
						} else if (user.role == "Prodavac") {
							$("#glavniDeoZajednicki").hide();
							$("#UserDeo").hide();
							$("#AdminDeo").hide();
							fillSellerData(user);
							$("#SellerDeo").show();
						} else if (user.role == "Admin") {
							$("#glavniDeoZajednicki").hide();
							$("#UserDeo").hide();
							$("#SellerDeo").hide();
							fillAdminData(user);
							$("#AdminDeo").show();
						}
					}
				},
				error: function () {
					showAlertModal("Greska, vrv niste ulogovani");
				}
			});
		}
	}
	//Popunjavanje personalne stranice korisnika ako je kupac
	function fillUserData(user) {
		$("#UserDeo").find("h4").text("Korisnik: " + user.name + " " + user.surname);
		$.get({
			url: "rest/ads/allAds",
			success: function (data) {
				$("#UserDeo").find("#userPorudzbine").find("table").find("tbody#userOrdersTable").empty();
				$("#UserDeo").find("#userDostavljeniProizvodi").find("table").find("tbody#userDeliveredTable").empty();
				$("#UserDeo").find("#userOmiljeniOglasi").find("table").find("tbody#UserFavouriteAds").empty();
				$("#UserDeo").find("#BuyerPorukeLista").find("table").find("tbody#BuyerMessagesTable").empty();
				for (var i = 0; i < data.length; i++) {

					if (data[i] !== null) {
						if (user.ordered.includes(data[i].id)) {
							let act = data[i].active ? 'DA' : 'NE';
							let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
								+ '<td>' + data[i].name + '</td>'
								+ '<td>' + data[i].price + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + act + '</td>'
								+ '<td>' + data[i].begindate + '</td>'
								+ '<td>' + data[i].enddate + '</td>'
								+ '<td><button type="button" class="btn btn-outline-success btn-sm" id="btnDostavljeno' + data[i].id + '">Oznaci kao dostavljeno</button></td>'
								+ '</tr>';
							$("#UserDeo").find("#userPorudzbine").find("table").find("tbody#userOrdersTable").append(por);
							$("#btnDostavljeno" + data[i].id).unbind();
							$("#btnDostavljeno" + data[i].id).click(markAsDelivered(data[i].id));
						}
						if (user.gotdelivered.includes(data[i].id)) {
							let act = data[i].active ? 'DA' : 'NE';
							let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
								+ '<td>' + data[i].name + '</td>'
								+ '<td>' + data[i].price + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + act + '</td>'
								+ '<td>' + data[i].begindate + '</td>'
								+ '<td>' + data[i].enddate + '</td>'
								+ '<td><button type="button" class="btn btn-outline-success btn-sm" id="btnPrijaviOglas' + data[i].id + '">Prijavi</button></td>'
								+ '</tr>';
							$("#UserDeo").find("#userDostavljeniProizvodi").find("table").find("tbody#userDeliveredTable").append(por);
							$("#UserDeo").find("#userDostavljeniProizvodi").find("table").find("#btnPrijaviOglas"+data[i].id).unbind();
							$("#UserDeo").find("#userDostavljeniProizvodi").find("table").find("#btnPrijaviOglas"+data[i].id).click(reportAd(data[i].id));
						}
						if (user.favourites.includes(data[i].id)) {
							let act = data[i].active ? 'DA' : 'NE';
							let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
								+ '<td>' + data[i].name + '</td>'
								+ '<td>' + data[i].price + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + act + '</td>'
								+ '<td>' + data[i].begindate + '</td>'
								+ '<td>' + data[i].enddate + '</td>'
								+ '<td><button type="button" class="btn btn-outline-success btn-sm" id="btnIzbrisiIzOmiljenih' + data[i].id + '">Ukloni</button></td>'
								+ '</tr>';
							$("#UserDeo").find("#userOmiljeniOglasi").find("table").find("tbody#UserFavouriteAds").append(por);
							$("#btnIzbrisiIzOmiljenih" + data[i].id).unbind();
							$("#btnIzbrisiIzOmiljenih" + data[i].id).click(ukloniIzOmiljenih(data[i].id));

						}

					}
				}
				let msgs = user.messages;
				for (var i = 0; i < msgs.length; i++) {
					let read = msgs[i].read;
					let a = read ? "" : "notread";
					if (msgs[i] != null) {
						let por = '<tr class="' + a + '"><td>' + msgs[i].adname + '</td>'
							+ '<td>' + msgs[i].user + '</td>'
							+ '<td>' + msgs[i].title + '</td>'
							+ '<td>' + msgs[i].content + '</td>'
							+ '<td>' + msgs[i].datetime + '</td>'
							+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"'
							+ 'aria-haspopup="true" aria-expanded="false">'
							+ 'Opcije'
							+ ' </a>'
							+ '<td><div class="dropdown-menu" aria-labelledby="navbarDropdown">'
							+ '<a class="dropdown-item" id="btnReadMessage' + msgs[i].id + '" href="#">Pogledaj poruku</a>'
							+ '<a class="dropdown-item" id="btnIzbrisiPorukuSeller' + msgs[i].id + '"  href="#">Ukloni poruku</a>'
							+ '<a class="dropdown-item" id="btnAnswerMessageList' + msgs[i].id + '"  href="#">Odgovori na poruku</a>'
							+ '</div></td>'
							+ '</td>'

							+ '</tr>';
						$("#UserDeo").find("#BuyerPorukeLista").find("table").find("tbody#BuyerMessagesTable").append(por);
						//	$("#btnIzbrisiIzOmiljenih"+data[i].id).unbind();
						//	$("#btnIzbrisiIzOmiljenih"+data[i].id).click(ukloniIzOmiljenih(data[i].id));
						$("#btnReadMessage" + msgs[i].id).unbind();
						$("#btnReadMessage" + msgs[i].id).click(readMessage(msgs[i]));
						$("#btnIzbrisiPorukuSeller" + msgs[i].id).unbind();
						$("#btnIzbrisiPorukuSeller" + msgs[i].id).click(deleteMessage(msgs[i].id));
						$("#btnAnswerMessageList" + msgs[i].id).unbind();
						$("#btnAnswerMessageList" + msgs[i].id).click(answerMessage(msgs[i]));
					}

				}
				$("#userOmiljeniOglasi").click();
				$("#userPorudzbine").click();


			},
			error: function () {
				showAlertModal("Greska pri ucitavanju");
			}
		});

	}
	function reportAd(id){
		return function(){
			$.get({
				url:"rest/admin/reportAd/"+id,
				success:function(){
					showAlertModal("Oglas uspesno prijavljen");
				},error:function(){
					showAlertModal("Neuspesno prijavljivanje oglasa");
				}
			});
		}
	}
	//Popunjavanje personalne stranice korisnika ako je admin
	function fillAdminData(user) {
		$("#AdminDeo").find("h4").text("Korisnik: " + user.name + " " + user.surname);
		$.get({
			url: "rest/ads/allAds",
			success: function (data) {
				$("#AdminDeo").find("#AdminSviOglasi").find("table").find("tbody#AdminSviOglasiTabela").empty();
				$("#AdminDeo").find("#AdminKorisnici").find("table").find("tbody#AdminAllUsersTable").empty();
				$("#AdminDeo").find("#AdminKategorije").find("table").find("tbody#AdminKategorijeTable").empty();
				$("#AdminDeo").find("#AdminPoruke").find("table").find("tbody#AdminPorukeTabela").empty();
				for (var i = 0; i < data.length; i++) {
					if (data[i] !== null) {
						let act = data[i].active ? 'DA' : 'NE';
						let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
							+ '<td>' + data[i].name + '</td>'
							+ '<td>' + data[i].price + '</td>'
							+ '<td>' + data[i].city + '</td>'
							+ '<td>' + act + '</td>'
							+ '<td>' + data[i].begindate + '</td>'
							+ '<td>' + data[i].enddate + '</td>'
							+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownAdminAds" role="button" data-toggle="dropdown"'
							+ 'aria-haspopup="true" aria-expanded="false">'
							+ 'Opcije'
							+ ' </a><div class="dropdown-menu" aria-labelledby="navbarDropdownAdminAds">'
							+ '<a class="dropdown-item" id="btnIzmeniOglasAdmin' + data[i].id + '" href="#">Izmeni</a>'
							+ '<a class="dropdown-item" id="brnUkloniOglasAdmin' + data[i].id + '"  href="#">Ukloni</a>'
							+ '</div></td>'
							+ '</tr>';
						$("#AdminDeo").find("#AdminSviOglasi").find("table").find("tbody#AdminSviOglasiTabela").append(por);
						$("#btnIzmeniOglasAdmin" + data[i].id).unbind();
						$("#btnIzmeniOglasAdmin" + data[i].id).click(changeAd(data[i]));
						$("#brnUkloniOglasAdmin" + data[i].id).unbind();
						$("#brnUkloniOglasAdmin" + data[i].id).click(deleteAd(data[i].id));
					}
				}
				let msgs = user.messages;
				for (var i = 0; i < msgs.length; i++) {
					let read = msgs[i].read;
					let a = read ? "" : "notread";
					if (msgs[i] != null) {
						let por = '<tr class="' + a + '"><td>' + msgs[i].adname + '</td>'
							+ '<td>' + msgs[i].user + '</td>'
							+ '<td>' + msgs[i].title + '</td>'
							+ '<td>' + msgs[i].content + '</td>'
							+ '<td>' + msgs[i].datetime + '</td>'
							+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"'
							+ 'aria-haspopup="true" aria-expanded="false">'
							+ 'Opcije'
							+ ' </a>'
							+ '<div class="dropdown-menu" aria-labelledby="navbarDropdown">'
							+ '<a class="dropdown-item" id="btnReadMessageAdmin' + msgs[i].id + '" href="#">Pogledaj poruku</a>'
							+ '<a class="dropdown-item" id="btnIzbrisiPorukuAdmin' + msgs[i].id + '"  href="#">Ukloni poruku</a>'
							+ '<a class="dropdown-item" id="btnAnswerMessageListAdmin' + msgs[i].id + '"  href="#">Odgovori na poruku</a>'
							+ '</div>'
							+ '</td>'

							+ '</tr>';
						$("#AdminDeo").find("#AdminPoruke").find("table").find("tbody#AdminPorukeTabela").append(por);
						//	$("#btnIzbrisiIzOmiljenih"+data[i].id).unbind();
						//	$("#btnIzbrisiIzOmiljenih"+data[i].id).click(ukloniIzOmiljenih(data[i].id));
						$("#btnReadMessageAdmin" + msgs[i].id).unbind();
						$("#btnReadMessageAdmin" + msgs[i].id).click(readMessage(msgs[i]));
						$("#btnIzbrisiPorukuAdmin" + msgs[i].id).unbind();
						$("#btnIzbrisiPorukuAdmin" + msgs[i].id).click(deleteMessage(msgs[i].id));
						$("#btnAnswerMessageListAdmin" + msgs[i].id).unbind();
						$("#btnAnswerMessageListAdmin" + msgs[i].id).click(answerMessage(msgs[i]));
					}

				}
				$.get({
					url: 'rest/admin/allUsers',
					success: function (data) {
						for (let i = 0; i < data.length; i++) {
							let por = '<tr><td>' + data[i].name + ' ' + data[i].surname + '</td>'
								+ '<td>' + data[i].username + '</td>'
								+ '<td>' + data[i].role + '</td>'
								+ '<td>' + data[i].phoneNumber + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + data[i].email + '</td>'
								+ '<td>' + data[i].date + '</td>'
								+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownAdminAds" role="button" data-toggle="dropdown"'
								+ 'aria-haspopup="true" aria-expanded="false">'
								+ 'Opcije'
								+ ' </a><div class="dropdown-menu" aria-labelledby="navbarDropdownAdminAds">'
								+ '<a class="dropdown-item" id="btnIzmeniKorisnikaAdmin' + data[i].id + '" href="#">Izmeni</a>'
								+ '<a class="dropdown-item" id="btnPosaljiPorukuAdmin' + data[i].id + '"  href="#">Posalji poruku</a>'
								+ '</div></td>'
								+ '</tr>';
							$("#AdminDeo").find("#AdminKorisnici").find("table").find("tbody#AdminAllUsersTable").append(por);
							$("#btnIzmeniKorisnikaAdmin" + data[i].id).unbind();
							$("#btnIzmeniKorisnikaAdmin" + data[i].id).click(changeUser(data[i]));
							$("#btnPosaljiPorukuAdmin" + data[i].id).unbind();
							$("#btnPosaljiPorukuAdmin" + data[i].id).click(function(){
								$("#modalAnswerMessage").find("#MsgAnswerTitle").val('');
								$("#modalAnswerMessage").find("#message-text-answer").val('');
								$("#modalAnswerMessage").find("#sender-name-answer").val('');
								$("#modalAnswerMessage").find("#btnAnswerMsgSend").unbind();
								$("#modalAnswerMessage").find("#btnAnswerMsgSend").click(sendMessageAdmin(data[i].id));
								$("#modalAnswerMessage").modal('toggle');
							});
						}
					}
				});
				$.get({
					url: 'rest/ads/cats',
					success: function (data) {
						for (let i = 0; i < data.length; i++) {
							let por = '<tr><td>' + data[i].name + '</td>'
								+ '<td>' + data[i].description + '</td>'
								+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownCatOptions" role="button" data-toggle="dropdown"'
								+ 'aria-haspopup="true" aria-expanded="false">'
								+ 'Opcije'
								+ ' </a>'
								+ '<div class="dropdown-menu" aria-labelledby="navbarDropdownCatOptions">'
								+ '<a class="dropdown-item" id="btnIzmeniKategorijuAdmin' + data[i].id + '" href="#">Izmeni</a>'
								+ '<a class="dropdown-item" id="btnUkloniKategoriju' + data[i].id + '"  href="#">Ukloni</a>'
								+ '</div>'
								+ '</td>'
								+ '</tr>';
							$("#AdminDeo").find("#AdminKategorije").find("table").find("tbody#AdminKategorijeTable").append(por);
							$("#btnIzmeniKategorijuAdmin" + data[i].id).unbind();
							$("#btnIzmeniKategorijuAdmin" + data[i].id).click(changeCategory(data[i]));
							$("#btnUkloniKategoriju" + data[i].id).unbind();
							$("#btnUkloniKategoriju" + data[i].id).click(deleteCategory(data[i].id));
						}
					}
				});
				$("#btnAddCategory").unbind();
				$("#btnAddCategory").click(addCategoryClick());
			},
			error: function () {
				showAlertModal("Greska pri ucitavanju");
			}
		});
	}
	function addCategoryClick() {
		return function () {
			$("#modalChangeCategory").find("h6").text('Dodavanje kategorije');
			$("#modalChangeCategory").find("#CatNameChange").val('');
			$("#modalChangeCategory").find("#CatDescChange").val('');
			$("#modalChangeCategory").find("#btnSendChangedCategory").text('Dodaj');
			$("#modalChangeCategory").find("#btnSendChangedCategory").unbind();
			$("#modalChangeCategory").find("#btnSendChangedCategory").click(function () {
				$.post({
					url: "rest/admin/addCat",
					contentType: "application/json",
					data: JSON.stringify({
						id: '',
						name: $("#modalChangeCategory").find("#CatNameChange").val(),
						description: $("#modalChangeCategory").find("#CatDescChange").val(),
						deleted: false
					}),
					success: function () {
						$("#modalChangeCategory").modal('toggle');
						showAlertModal("Kategorija uspesno dodata");
						showUserPage().call();
					}, error: function () {
						showAlertModal("Greska pri izmeni kategorije");
					}
				});
			});
			$("#modalChangeCategory").modal('toggle');
		}
	}
	function changeCategory(cat) {
		return function () {
			$("#modalChangeCategory").find("h6").text('Izmena kategorije');
			$("#modalChangeCategory").find("#CatNameChange").val(cat.name);
			$("#modalChangeCategory").find("#CatDescChange").val(cat.description);
			$("#modalChangeCategory").find("#btnSendChangedCategory").text('Izmeni');
			$("#modalChangeCategory").find("#btnSendChangedCategory").unbind();
			$("#modalChangeCategory").find("#btnSendChangedCategory").click(function () {
				$.post({
					url: "rest/admin/changeCat",
					contentType: "application/json",
					data: JSON.stringify({
						id: cat.id,
						name: $("#modalChangeCategory").find("#CatNameChange").val(),
						description: $("#modalChangeCategory").find("#CatDescChange").val(),
						deleted: false
					}),
					success: function () {
						$("#modalChangeCategory").modal('toggle');
						showAlertModal("Kategorija uspesno izmenjena");
						showUserPage().call();
					}, error: function () {
						showAlertModal("Greska pri izmeni kategorije");
					}
				});
			});
			$("#modalChangeCategory").modal('toggle');
		}
	}
	function deleteCategory(id) {
		return function () {
			$.ajax({
				type: "delete",
				url: "rest/admin/deleteCategory/" + id,
				success: function () {
					showAlertModal('Kategorija uspesno obrisana');
					showUserPage().call();
				}, error: function () {
					showAlertModal("Greska pri brisanju kategorije");
				}
			});
		}
	}
	function changeUser(user) {
		return function () {

			$("#modalChangeUser").find("#UserNameChange").val(user.name + ' ' + user.surname);
			$("#modalChangeUser").find("#selectUserRole option[value=" + user.role.substring(0, 1) + "]").prop('selected', true);
			$("#modalChangeUser").find("#btnSendChangedUser").unbind();
			$("#modalChangeUser").find("#btnSendChangedUser").click(function () {
				$.post({
					url: "rest/admin/changeUser/" + user.id,
					traditional: true,
					contentType: "text/html",
					data: $("#modalChangeUser").find("#selectUserRole option:selected").text(),
					success: function () {
						$("#modalChangeUser").modal('toggle');
						showAlertModal("korisnik uspesno izmenjen");
						showUserPage().call();
					}, error: function () {
						showAlertModal("Greska pri izmeni korisnika");
					}
				});
			});
			$("#modalChangeUser").modal('toggle');

		}
	}
	function markAsDelivered(id) {
		return function () {
			$.ajax({
				type: "put",
				url: "rest/ads/markAsDelivered/" + id,
				success: function (data) {
					showUserPage().call();
					showAlertModal('Oglas ' + data.name + ' oznacen kao dostavljen');
				},
				error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}
	}
	function ukloniIzOmiljenih(id) {
		return function () {
			$.ajax({
				type: "delete",
				url: "rest/ads/remove-favorite/" + id,
				success: function (data) {
					showUserPage().call();
					showAlertModal('Oglas ' + data.name + ' uspesno uklonjen iz omiljenih');
				},
				error: function () {
					showAlertModal('Neuspesno uklanjanje iz liste omiljenih');
				}
			});
		}
	}
	//Popunjavanje personalne stranice korisnika ako je prodavac
	function fillSellerData(user) {
		$("#SellerDeo").find("h4").text("Korisnik: " + user.name + " " + user.surname);
		$("#SellerDeo").find("#SellerLike").text("Broj lajkova: " + user.likes);
		$("#SellerDeo").find("#SellerDisLike").text("Broj dislajkova: " + user.dislikes);
		$.get({
			url: "rest/ads/allAds",
			success: function (data) {
				$("#SellerDeo").find("#SellerObjavljeniOglasi").find("table").find("tbody#SellerPublishedTable").empty();
				$("#SellerDeo").find("#SellerIsporuceniOglasi").find("table").find("tbody#SellerDeliveredTable").empty();
				$("#SellerDeo").find("#SellerPorukeLista").find("table").find("tbody#SellerMessagesTable").empty();
				for (var i = 0; i < data.length; i++) {
					if (data[i] !== null) {
						if (user.published.includes(data[i].id)) {
							let act = data[i].active ? 'DA' : 'NE';
							let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
								+ '<td>' + data[i].name + '</td>'
								+ '<td>' + data[i].price + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + act + '</td>'
								+ '<td>' + data[i].begindate + '</td>'
								+ '<td>' + data[i].enddate + '</td>'
								+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"'
								+ 'aria-haspopup="true" aria-expanded="false">'
								+ 'Opcije'
								+ ' </a>'
								+ '<div class="dropdown-menu" aria-labelledby="navbarDropdown">'
								+ '<a class="dropdown-item" id="btnObrisiOglas' + data[i].id + '" href="#">Ukloni oglas</a>'
								+ '<a class="dropdown-item" id="btnIzmeniOglas' + data[i].id + '"  href="#">Izmeni oglas</a>'
								+ '</div>'
								+ '</td>'
								+ '</tr>';
							$("#SellerDeo").find("#SellerObjavljeniOglasi").find("table").find("tbody#SellerPublishedTable").append(por);
							$("#btnObrisiOglas" + data[i].id).unbind();
							$("#btnObrisiOglas" + data[i].id).click(deleteAd(data[i].id));
							$("#btnIzmeniOglas" + data[i].id).unbind();
							$("#btnIzmeniOglas" + data[i].id).click(changeAd(data[i]));
						}
						if (user.delivered.includes(data[i].id)) {
							let act = data[i].active ? 'DA' : 'NE';
							let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
								+ '<td>' + data[i].name + '</td>'
								+ '<td>' + data[i].price + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + act + '</td>'
								+ '<td>' + data[i].begindate + '</td>'
								+ '<td>' + data[i].enddate + '</td>'
								//+'<td><button type="button" class="btn btn-outline-success btn-sm" id="btnOstaviRec'+data[i].id+'">Recenziraj</button></td>'
								+ '</tr>';
							$("#SellerDeo").find("#SellerIsporuceniOglasi").find("table").find("tbody#SellerDeliveredTable").append(por);
						}

					}
				}
				let msgs = user.messages;
				for (var i = 0; i < msgs.length; i++) {
					let read = msgs[i].read;
					let a = read ? "" : "notread";
					if (msgs[i] != null) {
						let por = '<tr class="' + a + '"><td>' + msgs[i].adname + '</td>'
							+ '<td>' + msgs[i].user + '</td>'
							+ '<td>' + msgs[i].title + '</td>'
							+ '<td>' + msgs[i].content + '</td>'
							+ '<td>' + msgs[i].datetime + '</td>'
							+ '<td><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"'
							+ 'aria-haspopup="true" aria-expanded="false">'
							+ 'Opcije'
							+ ' </a>'
							+ '<div class="dropdown-menu" aria-labelledby="navbarDropdown">'
							+ '<a class="dropdown-item" id="btnReadMessage' + msgs[i].id + '" href="#">Pogledaj poruku</a>'
							+ '<a class="dropdown-item" id="btnIzbrisiPorukuSeller' + msgs[i].id + '"  href="#">Ukloni poruku</a>'
							+ '<a class="dropdown-item" id="btnAnswerMessageList' + msgs[i].id + '"  href="#">Odgovori na poruku</a>'
							+ '</div>'
							+ '</td>'

							+ '</tr>';
						$("#SellerDeo").find("#SellerPorukeLista").find("table").find("tbody#SellerMessagesTable").append(por);
						//	$("#btnIzbrisiIzOmiljenih"+data[i].id).unbind();
						//	$("#btnIzbrisiIzOmiljenih"+data[i].id).click(ukloniIzOmiljenih(data[i].id));
						$("#btnReadMessage" + msgs[i].id).unbind();
						$("#btnReadMessage" + msgs[i].id).click(readMessage(msgs[i]));
						$("#btnIzbrisiPorukuSeller" + msgs[i].id).unbind();
						$("#btnIzbrisiPorukuSeller" + msgs[i].id).click(deleteMessage(msgs[i].id));
						$("#btnAnswerMessageList" + msgs[i].id).unbind();
						$("#btnAnswerMessageList" + msgs[i].id).click(answerMessage(msgs[i]));
					}

				}
				$("#userPorudzbineDodajOglas").unbind();
				$("#userPorudzbineDodajOglas").click(AdAdd());
			},
			error: function () {
				showAlertModal("Greska pri ucitavanju");
			}
		});

	}
	$("#pocetnaLink").click(function () {
		$("#glavniDeoZajednicki").show();
		$("#UserDeo").hide();
		$("#SellerDeo").hide();
		$("#AdminDeo").hide();
	});
	//klik na dugme izbrisi oglas
	function deleteAd(id) {
		return function () {
			$.ajax({
				type: "delete",
				url: "rest/ads/deleteAd/" + id,
				success: function () {
					showUserPage().call();
					showAlertModal("Oglas uspesno uklonjen");
				},
				error: function () {
					showAlertModal("Neuspesno uklanjanje oglasa");
				}
			});
		}
	}
	//Rad sa porukama
	function readMessage(msg) {
		return function () {

			$.post({
				url: "rest/ads/msgRead/" + msg.id,
				success: function (u) {
					showUserPage().call();
					$("#modalShowMessage").find("#naslovPoruke").text(msg.title);
					$("#modalShowMessage").find("#porukaZaOglas").text("Za oglas: " + msg.adname);
					$("#modalShowMessage").find("#message-date").text('Poslata: ' + msg.datetime);
					$("#modalShowMessage").find("#sender-name").val(u.name + ' ' + u.surname);
					$("#modalShowMessage").find("#message-text").text(msg.content);
					$("#modalShowMessage").find("#btnAnswerMsg").unbind()
					$("#modalShowMessage").find("#btnAnswerMsg").click(answerMessage(msg));
					$("#modalShowMessage").modal('toggle');
				},
				error: function () {
					showAlertModal(msg.responseText);
				}
			});
		}

	}
	function answerMessage(msg) {
		return function () {
			let ovo = $(this);
			$.post({
				url: "rest/ads/msgRead/" + msg.id,
				success: function (u) {
					if (ovo.attr("id") == "btnAnswerMsg") {
						$("#modalShowMessage").modal('toggle');
					}
					$("#modalAnswerMessage").find("#MsgAnswerTitle").val('');
					$("#modalAnswerMessage").find("#message-text-answer").val('');
					$("#modalAnswerMessage").find("#sender-name-answer").val(u.name + ' ' + u.surname);
					$("#modalAnswerMessage").find("#btnAnswerMsgSend").unbind();
					$("#modalAnswerMessage").find("#btnAnswerMsgSend").click(answerMessageSend(msg, u));
					$("#modalAnswerMessage").modal('toggle');
				},
				error: function () {
					showAlertModal(msg.responseText);
				}
			});
		}
	}

	function answerMessageSend(msg, u) {
		return function () {
			$.post({
				url: "rest/ads/msgAnswerSend/" + msg.user,
				contentType: "application/json",
				data: JSON.stringify({
					id: msg.id.substring(21, msg.id.length),
					adname: msg.adname,
					user: '',
					title: $("#modalAnswerMessage").find("#MsgAnswerTitle").val(),
					content: $("#modalAnswerMessage").find("#message-text-answer").val(),
					datetime: '',
					read: false
				}),
				success: function (data) {
					$("#modalAnswerMessage").modal('toggle');
					showAlertModal("Poruka uspesno poslata");
				},
				error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}
	}
	function sendMessageAdmin(u) {
		return function () {
			$.post({
				url: "rest/admin/msgAdminSend/" + u,
				contentType: "application/json",
				data: JSON.stringify({
					id: '',
					adname: '',
					user: '',
					title: $("#modalAnswerMessage").find("#MsgAnswerTitle").val(),
					content: $("#modalAnswerMessage").find("#message-text-answer").val(),
					datetime: '',
					read: false
				}),
				success: function (data) {
					$("#modalAnswerMessage").modal('toggle');
					showAlertModal("Poruka uspesno poslata");
				},
				error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}
	}
	function deleteMessage(id) {
		return function () {
			$.ajax({
				type: "delete",
				url: "rest/ads/deleteMsg/" + id,
				success: function () {
					showUserPage().call();
					showAlertModal('Poruka uspesno obrisana');
				}, error: function () {
					showAlertModal('Neuspesno brisanje poruke');
				}
			});
		}

	}
	//otvaranje modala za izmenu oglasa
	function changeAd(ad) {
		return function () {
			$("#modalChangeAd").find("h6").text("Izmena oglasa");
			$("#modalChangeAd").find("#AdTitleChange").val(ad.name);
			$("#modalChangeAd").find("#AdDescriptionTextarea").val(ad.description);
			$("#modalChangeAd").find("#AdPriceChange").val(ad.price);
			$("#modalChangeAd").find("#AdCityChange").val(ad.city);
			$("#modalChangeAd").find("#AdActiveChange").prop("checked", ad.active);
			$("#modalChangeAd").find("#AdCategorySelection").empty();
			$("#modalChangeAd").find("#AdCategorySelection").append('<option selected>' + ad.category + '</option>');
			$('#v-pills-tab').find("a").get().forEach(function (element) {
				if (element.id != ad.category && element.id != 'mostPopular' && element.id != 'allCateg' && element.id != undefined && element.id != 'labelCategoryKategorije' && element.id != 'navBtnAddCat') {
					$("#modalChangeAd").find("#AdCategorySelection").append('<option selected>' + element.id + '</option>');
				}
			});
			$("#modalChangeAd").find("#btnSendChangedAd").unbind();
			$("#modalChangeAd").find("#btnSendChangedAd").text('Izmeni');
			$("#modalChangeAd").find("#btnSendChangedAd").click(sendChangedAd(ad));
			$("#modalChangeAd").modal('toggle');
		}
	}
	//otvaranje modala za dodavanje oglasa (Koristi se isti modal kao za izmenu)
	function AdAdd() {
		return function () {
			$("#modalChangeAd").find("h6").text("Dodavanje oglasa");
			$("#modalChangeAd").find("#AdTitleChange").val("");
			$("#modalChangeAd").find("#AdDescriptionTextarea").val('');
			$("#modalChangeAd").find("#AdPriceChange").val('');
			$("#modalChangeAd").find("#AdCityChange").val('');
			$("#modalChangeAd").find("#AdActiveChange").prop("checked", false);
			$('#v-pills-tab').get().forEach(function (element) {
				if (element.id != 'mostPopular' && element.id != 'allCateg' && element.id != undefined) {
					$("#modalChangeAd").find("#AdCategorySelection").append('<option selected>' + element.id + '</option>');
				}
			});
			$("#modalChangeAd").find("#btnSendChangedAd").unbind();
			$("#modalChangeAd").find("#btnSendChangedAd").text('Dodaj');
			$("#modalChangeAd").find("#btnSendChangedAd").click(sendNewAd());
			$("#modalChangeAd").modal('toggle');
		}
	}
	//posalji izmenjen oglas
	function sendChangedAd(ad) {
		return function (e) {
			e.preventDefault();
			e.preventDefault();
			//To-Do: poslati novi oglas na server
			let data = new FormData();
			let oglas = JSON.stringify({
				id: ad.id,
				name: $("#modalChangeAd").find("#AdTitleChange").val(),
				description: $("#modalChangeAd").find("#AdDescriptionTextarea").val(),
				price: $("#modalChangeAd").find("#AdPriceChange").val(),
				city: $("#modalChangeAd").find("#AdCityChange").val(),
				active: $("#modalChangeAd").find("#AdActiveChange").is(":checked"),
				seller: ad.seller,
				likes: ad.likes,
				dislikes: ad.dislikes,
				active: true,
				deleted: false,
				image: '',
				category: $("#modalChangeAd").find("#AdCategorySelection option:selected").text()

			});
			let objFile = $("#PictureUploadAd");
			let file = objFile[0].files[0];
			let fileName = file == undefined ? '' : file.name;
			data.append('Oglas', oglas);
			data.append('fajl', file);
			data.append('slika', fileName);
			$.post({
				url: "rest/ads/changeAd",
				data: data,
				contentType: false,
				processData: false,
				success: function () {
					showUserPage().call();
					showAlertModal("izmena oglasa uspesna");
					$("#modalChangeAd").modal('toggle');
				}, error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}
	}
	function sendNewAd() {
		return function (e) {
			e.preventDefault();
			//To-Do: poslati novi oglas na server
			let data = new FormData();
			let oglas = JSON.stringify({
				id: '',
				name: $("#modalChangeAd").find("#AdTitleChange").val(),
				description: $("#modalChangeAd").find("#AdDescriptionTextarea").val(),
				price: $("#modalChangeAd").find("#AdPriceChange").val(),
				city: $("#modalChangeAd").find("#AdCityChange").val(),
				active: $("#modalChangeAd").find("#AdActiveChange").is(":checked"),
				seller: '',
				likes: 0,
				dislikes: 0,
				active: true,
				deleted: false,
				image: '',
				category: $("#modalChangeAd").find("#AdCategorySelection option:selected").text()

			});
			let objFile = $("#PictureUploadAd");
			let file = objFile[0].files[0];
			let fileName = file == undefined ? '' : file.name;
			data.append('Oglas', oglas);
			data.append('fajl', file);
			data.append('slika', fileName);
			$.post({
				url: "rest/ads/dodajOglas",
				data: data,
				contentType: false,
				processData: false,
				success: function () {
					$("#modalChangeAd").modal('toggle');
					showAlertModal("USPEH");
					showUserPage().call();

				},
				error: function (msg) {
					showAlertModal(msg.responseText);
				}
			});
		}

	}
	$("#modalSearchUser").find("#btnmodalSearchUsers").click(function () {
		$.post({
			url: "rest/admin/getSearchUsers",
			contentType: "application/json",
			data: JSON.stringify({
				ime: $("#UserNameSearch").val(),
				grad: $("#UserCitySearch").val()
			}),
			success: function (data) {
				if (data != null) {
					$("#UserSearchResults").find("table").find("tbody#UserSearchResultsTable").empty();
					for (let i = 0; i < data.length; i++) {
						let por = '<tr><td>' + data[i].name + ' ' + data[i].surname + '</td>'
							+ '<td>' + data[i].username + '</td>'
							+ '<td>' + data[i].role + '</td>'
							+ '<td>' + data[i].phoneNumber + '</td>'
							+ '<td>' + data[i].city + '</td>'
							+ '<td>' + data[i].email + '</td>'
							+ '<td>' + data[i].date + '</td>'
							+ '</tr>';
						$("#UserSearchResults").find("table").find("tbody#UserSearchResultsTable").append(por);
					}
					$("#modalSearchUser").modal('toggle');
					$("#UserSearchResults").modal('toggle');
				}
			}, error: function () {
				showAlertModal("Doslo je do greske pri pretrazi");

			}
		});
	});
	$("#modalSearchAds").find("#btnmodalSearchAds").click(function () {
		$.post({
			url: "rest/admin/searchAds",
			contentType: "application/json",
			data: JSON.stringify({
				nameOglas: $("#AdNameSearch").val(),
				minPrice: $("#AdpriceLowSearch").val(),
				maxPrice: $("#AdpriceHighSearch").val(),
				minLikes: $("#AdLikeLowSearch").val(),
				maxLikes: $("#AdLikeHighSearch").val(),
				minDate: $("#AdDateLowSearch").val(),
				maxDate: $("#AdDateHighSearch").val(),
				city: $("#selectAdCity").find(":selected").text(),
			}),
			success: function (data) {
				if (data != null) {
					$("#AdsSearchResults").find("table").find("tbody#AdsSearchResultsTable").empty();
					for (var i = 0; i < data.length; i++) {
						if (data[i] !== null) {
							let act = data[i].active ? 'DA' : 'NE';
							let por = '<tr><td><img src="' + data[i].image + '" onerror="this.src = \'images/no-image.jpg\';" class="AdIcon"></td>'
								+ '<td>' + data[i].name + '</td>'
								+ '<td>' + data[i].price + '</td>'
								+ '<td>' + data[i].city + '</td>'
								+ '<td>' + act + '</td>'
								+ '<td>' + data[i].begindate + '</td>'
								+ '<td>' + data[i].enddate + '</td>'

								+ '</tr>';
							$("#AdsSearchResults").find("table").find("tbody#AdsSearchResultsTable").append(por);

						}
					}
				}
				$("#modalSearchAds").modal('toggle');
				$("#AdsSearchResults").modal('toggle');
			}, error: function () {
				showAlertModal("Doslo je do greske pri pretrazi");
			}
		});
	});
	$("#linkPretragaKorisnika").click(function () {
		$.get({
			url: "rest/admin/getCities",
			success: function (data) {
				por = '<option></option>';
				$("#selectAdCity").append(por);
				for (let i = 0; i < data.length; i++) {
					por = '<option>' + data[i] + '</option>';
					$("#selectAdCity").append(por);
				}
				$("#modalSearchAds").modal('toggle');
			},
			error: function () {
				showAlertModal("Neuspesno ucitavanje gradova!");
			}
		});
	});
});
function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();

		reader.onload = function (e) {
			$('#SelectedAdImage')
				.attr('src', e.target.result)
				.width(150)
				.height(200);
		};

		reader.readAsDataURL(input.files[0]);
	}
}